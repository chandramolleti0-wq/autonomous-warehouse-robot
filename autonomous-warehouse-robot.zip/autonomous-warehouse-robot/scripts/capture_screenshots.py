"""Render real screenshots of the running simulator (works without a display).

    python scripts/capture_screenshots.py

Runs the demo headlessly with SDL's dummy video driver and saves PNGs of the
actual UI into assets/screenshots/ at meaningful moments of the run.
"""
import os
import sys
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import pygame                                   # noqa: E402

from src.config import load_config              # noqa: E402
from src.robot import RobotState                # noqa: E402
from src.simulation import Simulation           # noqa: E402
from src.ui import App                          # noqa: E402

OUT = ROOT / "assets" / "screenshots"
OUT.mkdir(parents=True, exist_ok=True)


def shot(app, name):
    app.render()
    pygame.image.save(app.screen, str(OUT / name))
    print("saved", OUT / name)


def run_until(app, predicate, limit=300.0, dt=1 / 30):
    t = 0.0
    while t < limit and not predicate():
        app.sim.update(dt)
        t += dt
    return predicate()


def main():
    sim = Simulation(load_config(ROOT / "config" / "warehouse.json"))
    app = App(sim)
    shot(app, "01_initial_warehouse.png")

    app.say(sim.add_demo_tasks())
    sim.start()
    robot = sim.robot

    run_until(app, lambda: robot.state is RobotState.PLANNING and robot.plan_progress > 0.6)
    shot(app, "02_astar_planning_explored_nodes.png")

    run_until(app, lambda: sim.metrics.replans >= 1 and robot.state is RobotState.PLANNING)
    run_until(app, lambda: robot.state is RobotState.MOVING and sim.metrics.replans >= 1)
    run_until(app, lambda: robot.route_remaining > 4, limit=5)
    shot(app, "03_obstacle_replan.png")

    run_until(app, lambda: robot.state is RobotState.PICKING and robot.target_detection is not None)
    shot(app, "04_package_recognition.png")

    run_until(app, lambda: robot.state is RobotState.DELIVERING and robot.sub is None
              and robot.route_remaining > 5)
    shot(app, "05_delivering.png")

    run_until(app, lambda: sim.metrics.tasks_completed == 4, limit=600)
    run_until(app, lambda: robot.cell == sim.warehouse.charger, limit=60)
    shot(app, "06_all_tasks_completed.png")

    # OpenCV recognition mode with synthetic camera thumbnail
    sim2 = Simulation(load_config(ROOT / "config" / "warehouse.json"))
    sim2.set_recognition_mode("opencv")
    app.sim = sim2
    sim2.add_task("PKG-010", "D2")
    sim2.start()
    run_until(app, lambda: sim2.robot.state is RobotState.PICKING
              and sim2.robot.target_detection is not None)
    shot(app, "07_opencv_recognition.png")
    pygame.quit()


if __name__ == "__main__":
    main()
