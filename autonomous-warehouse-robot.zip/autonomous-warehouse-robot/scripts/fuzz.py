"""Stress test: random tasks, random speeds/recognition modes, crates dropped mid-run.

Usage:  python scripts/fuzz.py [num_seeds]
Checks safety invariants (no collisions, never inside blocked cells) and that
every run terminates. Prints task outcomes and failure reasons.
"""
import copy
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from src.robot import RobotState          # noqa: E402
from src.simulation import Simulation     # noqa: E402

raw = json.loads((ROOT / "config" / "warehouse.json").read_text())
seeds = int(sys.argv[1]) if len(sys.argv) > 1 else 40
tot = dict(done=0, failed=0, collisions=0, timeouts=0, replans=0, obstacles=0)
reasons: dict[str, int] = {}
for seed in range(seeds):
    rng = random.Random(seed)
    cfg = copy.deepcopy(raw)
    cfg["robot"]["speed_cells_per_s"] = rng.choice([2.0, 3.0, 5.0])
    cfg["recognition"]["mode"] = rng.choice(["sensor", "opencv"])
    sim = Simulation(cfg)
    ids = [p.id for p in sim.packages.all()]
    rng.shuffle(ids)
    for pid in ids[:rng.randint(3, 8)]:
        sim.add_task(pid, rng.choice(["D1", "D2", "D3"]))
    sim.start()
    wh = sim.warehouse
    while sim.time < 1500:
        sim.update(0.05)
        if rng.random() < 0.01:
            sim.toggle_crate((rng.randint(1, 24), rng.choice([2, 5, 8, 11, 13])))
        for c in sim.robot.occupied_cells():
            assert not wh.is_static_blocked(c) and c not in wh.package_at, (seed, c)
        r = sim.robot
        if r.latched or (not sim.tasks.has_queued() and r.task is None
                         and r.cell == wh.charger and r.state is RobotState.IDLE):
            break
    m = sim.metrics
    if sim.time >= 1500:
        tot["timeouts"] += 1
        print(f"seed {seed}: TIMEOUT in {sim.robot.state.value} ({sim.robot.phase})")
    tot["done"] += m.tasks_completed
    tot["failed"] += m.tasks_failed
    tot["collisions"] += m.collisions
    tot["replans"] += m.replans
    tot["obstacles"] += m.obstacles_encountered
    for t in sim.tasks.history:
        if t.failure_reason:
            key = t.failure_reason.split("(")[0].strip()
            reasons[key] = reasons.get(key, 0) + 1
print(tot)
print("failure reasons:", reasons or "none")
assert tot["collisions"] == 0 and tot["timeouts"] == 0
print("FUZZ OK")
