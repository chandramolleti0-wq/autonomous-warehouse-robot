"""Task validation, queueing and end-to-end task execution tests."""
import copy
import json
from pathlib import Path

import pytest

from src.package_manager import PackageStatus
from src.robot import RobotState
from src.simulation import Simulation
from src.task_manager import TaskStatus

CONFIG = Path(__file__).resolve().parent.parent / "config" / "warehouse.json"


@pytest.fixture
def raw():
    return json.loads(CONFIG.read_text())


@pytest.fixture
def quiet(raw):
    """Same warehouse without movable obstacles (deterministic travel)."""
    cfg = copy.deepcopy(raw)
    cfg["movable_obstacles"] = []
    return cfg


# ------------------------------------------------------------ validation
def test_valid_task_is_queued():
    sim = Simulation.from_file(CONFIG)
    res = sim.add_task("pkg-001", " d1 ")        # normalised
    assert res.ok and res.task.package_id == "PKG-001" and res.task.destination == "D1"
    assert sim.packages.get("PKG-001").status is PackageStatus.ASSIGNED
    assert len(sim.tasks.queue) == 1


@pytest.mark.parametrize("pkg,dest,fragment", [
    ("PKG-999", "D1", "Invalid package ID"),
    ("", "D1", "package ID"),
    ("PKG-001", "D9", "Unknown destination"),
    ("PKG-001", "", "destination"),
])
def test_invalid_inputs_rejected(pkg, dest, fragment):
    sim = Simulation.from_file(CONFIG)
    res = sim.add_task(pkg, dest)
    assert not res.ok and fragment in res.message
    assert len(sim.tasks.queue) == 0
    assert sim.packages.get("PKG-001").status is PackageStatus.STORED


def test_cannot_assign_package_twice():
    sim = Simulation.from_file(CONFIG)
    assert sim.add_task("PKG-001", "D1").ok
    res = sim.add_task("PKG-001", "D2")
    assert not res.ok and "already assigned" in res.message
    assert len(sim.tasks.queue) == 1


def test_delivered_package_cannot_be_requested_again(quiet):
    sim = Simulation(quiet)
    assert sim.add_task("PKG-001", "D1").ok
    assert sim.run_until_idle()
    res = sim.add_task("PKG-001", "D2")
    assert not res.ok and "already delivered" in res.message


def test_unreachable_destination_rejected(raw):
    cfg = copy.deepcopy(raw)
    # wall off D1's whole row segment (x=3..5, y=12) from every side
    rows = [list(r) for r in cfg["layout"]]
    for x in range(2, 7):
        rows[11][x] = "#"
        rows[13][x] = "#"
    rows[12][2] = "#"
    rows[12][6] = "#"
    cfg["layout"] = ["".join(r) for r in rows]
    sim = Simulation(cfg)
    res = sim.add_task("PKG-001", "D1")
    assert not res.ok and "unreachable" in res.message.lower()
    assert sim.add_task("PKG-001", "D2").ok            # other destinations still fine


def test_unreachable_package_rejected(raw):
    cfg = copy.deepcopy(raw)
    rows = [list(r) for r in cfg["layout"]]
    # Enclose PKG-001's only access cell (3,2): passes config validation
    # (the neighbour is floor) but is cut off from the robot at runtime.
    for x, y in ((2, 2), (4, 2), (3, 1)):
        rows[y][x] = "#"
    cfg["layout"] = ["".join(r) for r in rows]
    sim = Simulation(cfg)
    res = sim.add_task("PKG-001", "D1")
    assert not res.ok and "unreachable" in res.message.lower()
    assert sim.packages.get("PKG-001").status is PackageStatus.STORED


def test_package_with_no_free_neighbour_is_a_config_error(raw):
    from src.config import ConfigError
    cfg = copy.deepcopy(raw)
    rows = [list(r) for r in cfg["layout"]]
    rows[2][3] = "#"                       # seals PKG-001 (3,3) completely
    cfg["layout"] = ["".join(r) for r in rows]
    with pytest.raises(ConfigError, match="no accessible neighbour"):
        Simulation(cfg)


def test_fifo_queue_order():
    sim = Simulation.from_file(CONFIG)
    sim.add_task("PKG-002", "D1")
    sim.add_task("PKG-003", "D2")
    assert [t.package_id for t in sim.tasks.queue] == ["PKG-002", "PKG-003"]


# ------------------------------------------------------------- execution
def test_single_task_end_to_end(quiet):
    sim = Simulation(quiet)
    assert sim.add_task("PKG-001", "D1").ok
    assert sim.run_until_idle(max_time=300)
    pkg = sim.packages.get("PKG-001")
    assert pkg.status is PackageStatus.DELIVERED
    assert pkg.delivered_cell == sim.warehouse.delivery_points["D1"]
    task = sim.tasks.history[0]
    assert task.status is TaskStatus.COMPLETED and task.duration > 0
    m = sim.metrics
    assert m.tasks_completed == 1 and m.tasks_failed == 0
    assert m.distance_cells > 20 and m.energy_used > 0 and m.collisions == 0
    assert m.completion_times == [task.duration]
    assert sim.robot.carrying is None


def test_pickup_happens_next_to_package_not_on_it(quiet):
    sim = Simulation(quiet)
    sim.add_task("PKG-005", "D1")
    sim.start()
    seen_pick_cells = set()
    while sim.time < 120 and sim.metrics.tasks_completed == 0:
        sim.update(0.05)
        if sim.robot.state is RobotState.PICKING:
            seen_pick_cells.add(sim.robot.cell)
    (cell,) = seen_pick_cells
    px, py = sim.packages.get("PKG-005").home_cell
    assert abs(cell[0] - px) + abs(cell[1] - py) == 1


def test_multiple_tasks_complete_in_order(quiet):
    sim = Simulation(quiet)
    for pkg, dest in (("PKG-001", "D1"), ("PKG-009", "D2"), ("PKG-010", "D2")):
        assert sim.add_task(pkg, dest).ok
    assert sim.run_until_idle(max_time=600)
    assert sim.metrics.tasks_completed == 3 and sim.metrics.tasks_failed == 0
    finished = [t.package_id for t in sorted(sim.tasks.history, key=lambda t: t.finished_at)]
    assert finished == ["PKG-001", "PKG-009", "PKG-010"]


def test_robot_identifies_requested_package_among_two_neighbours(quiet):
    sim = Simulation(quiet)
    # (9,2) touches PKG-009 at (9,1) and PKG-010 at (9,3)
    sim.add_task("PKG-010", "D2")
    sim.start()
    detections = None
    while sim.time < 60 and sim.robot.state is not RobotState.PICKING:
        sim.update(0.05)
    detections = list(sim.robot.detections)
    assert sim.robot.state is RobotState.PICKING
    ids = {d.package_id for d in detections}
    assert "PKG-010" in ids
    assert sim.run_until_idle(max_time=300)
    assert sim.packages.get("PKG-010").status is PackageStatus.DELIVERED
    assert sim.packages.get("PKG-009").status is PackageStatus.STORED   # untouched


def test_states_visited(quiet):
    sim = Simulation(quiet)
    sim.add_task("PKG-001", "D1")
    sim.start()
    seen = set()
    while sim.time < 120 and not (sim.metrics.tasks_completed and sim.robot.state is RobotState.IDLE):
        sim.update(0.05)
        seen.add(sim.robot.state)
    assert {RobotState.PLANNING, RobotState.MOVING, RobotState.PICKING,
            RobotState.DELIVERING, RobotState.COMPLETED, RobotState.IDLE} <= seen


def test_robot_never_enters_blocked_cells(raw):
    sim = Simulation(raw)
    sim.add_demo_tasks()
    sim.start()
    wh = sim.warehouse
    while sim.time < 400 and not (sim.tasks.history and not sim.tasks.has_queued()
                                  and sim.robot.task is None and sim.robot.cell == wh.charger):
        sim.update(0.05)
        for c in sim.robot.occupied_cells():
            assert not wh.is_static_blocked(c)
            assert c not in wh.package_at
    assert sim.metrics.collisions == 0


# --------------------------------------------------------------- failures
def test_task_fails_cleanly_when_destination_is_boxed_in(quiet):
    quiet["robot"]["max_blocked_wait_s"] = 4.0
    quiet["robot"]["obstacle_memory_s"] = 30.0
    sim = Simulation(quiet)
    sim.add_task("PKG-002", "D1")
    sim.start()
    # let the robot pick the package, then box D1 in with crates
    while sim.time < 120 and sim.packages.get("PKG-002").status is not PackageStatus.CARRIED:
        sim.update(0.05)
    dx, dy = sim.warehouse.delivery_points["D1"]
    for c in ((dx - 1, dy), (dx + 1, dy), (dx, dy - 1), (dx, dy + 1)):
        sim.warehouse.add_crate(c, sim.robot.occupied_cells())
    for _ in range(int(120 / 0.05)):
        sim.update(0.05)
        if sim.metrics.tasks_failed:
            break
    assert sim.metrics.tasks_failed == 1
    assert sim.tasks.history[0].status is TaskStatus.FAILED
    assert sim.robot.state is RobotState.ERROR and sim.robot.latched   # still carrying
    assert sim.metrics.collisions == 0


def test_failed_pickup_releases_package(quiet):
    sim = Simulation(quiet)
    sim.add_task("PKG-001", "D1")
    sim.recognition_mode = "sensor"
    sim.recognizers["sensor"].categories = {"electronics": (220, 50, 50)}   # sabotage colour table
    sim.recognizers["sensor"].categories["other"] = (30, 100, 220)          # forces category mismatch
    sim.run_until_idle(max_time=120)
    assert sim.metrics.tasks_failed == 1
    assert sim.packages.get("PKG-001").status is PackageStatus.STORED
    assert "category" in sim.tasks.history[0].failure_reason


# ------------------------------------------------------------- battery
def test_low_battery_triggers_charge_before_task(quiet):
    sim = Simulation(quiet)
    sim.robot.battery = 15.0                       # below the energy this task needs
    sim.add_task("PKG-006", "D3")
    sim.start()
    states = set()
    while sim.time < 300 and sim.metrics.tasks_completed == 0:
        sim.update(0.05)
        states.add(sim.robot.state)
    assert RobotState.CHARGING in states
    assert sim.metrics.tasks_completed == 1


def test_task_exceeding_battery_capacity_fails(quiet):
    quiet["robot"]["battery"] = {"capacity": 20.0, "reserve": 10.0}
    sim = Simulation(quiet)
    sim.add_task("PKG-008", "D1")
    sim.run_until_idle(max_time=60)
    assert sim.metrics.tasks_failed == 1
    assert "capacity" in sim.tasks.history[0].failure_reason
