"""Unit tests for the from-scratch A* implementation."""
import random
from collections import deque

import pytest

from src.path_planning import DIRECTIONS, GridMap, astar, manhattan


def bfs_cost(grid: GridMap, start, goal):
    """Independent shortest-path reference (breadth-first search)."""
    if start == goal:
        return 0
    seen = {start}
    queue = deque([(start, 0)])
    while queue:
        cell, d = queue.popleft()
        for dx, dy in DIRECTIONS:
            nb = (cell[0] + dx, cell[1] + dy)
            if nb in seen or not grid.passable(nb):
                continue
            if nb == goal:
                return d + 1
            seen.add(nb)
            queue.append((nb, d + 1))
    return None


def assert_valid_path(grid, path):
    for cell in path:
        assert grid.passable(cell), f"path crosses blocked cell {cell}"
    for a, b in zip(path, path[1:]):
        assert manhattan(a, b) == 1, f"illegal (non 4-connected) step {a}->{b}"


# ------------------------------------------------------------- valid paths
def test_manhattan_distance():
    assert manhattan((0, 0), (3, 4)) == 7
    assert manhattan((2, 2), (2, 2)) == 0


def test_straight_path_on_empty_grid():
    grid = GridMap(10, 10)
    res = grid.find_path((0, 0), (5, 0))
    assert res.found
    assert res.path[0] == (0, 0) and res.path[-1] == (5, 0)
    assert res.cost == 5 == len(res.path) - 1
    assert_valid_path(grid, res.path)


def test_start_equals_goal():
    res = GridMap(3, 3).find_path((1, 1), (1, 1))
    assert res.found and res.path == [(1, 1)] and res.cost == 0


def test_path_goes_around_wall_and_is_optimal():
    grid = GridMap.from_ascii([
        ".....",
        ".###.",
        ".....",
    ])
    res = grid.find_path((0, 1), (4, 1))
    assert res.found
    assert_valid_path(grid, res.path)
    assert res.cost == bfs_cost(grid, (0, 1), (4, 1)) == 6


def test_explored_nodes_are_unique_and_start_first():
    grid = GridMap(8, 8, blocked={(3, y) for y in range(7)})
    res = grid.find_path((0, 0), (7, 0))
    assert res.found
    assert res.explored[0] == (0, 0)
    assert res.explored[-1] == (7, 0)
    assert len(set(res.explored)) == len(res.explored)


def test_multiple_goals_pick_nearest():
    grid = GridMap(10, 3)
    res = grid.find_path((0, 1), [(9, 1), (3, 1), (6, 1)])
    assert res.found and res.path[-1] == (3, 1) and res.cost == 3


# ------------------------------------------------------------- unreachable
def test_unreachable_goal_enclosed_by_walls():
    grid = GridMap.from_ascii([
        ".....",
        ".###.",
        ".#.#.",
        ".###.",
        ".....",
    ])
    res = grid.find_path((0, 0), (2, 2))
    assert not res.found
    assert res.path == []


def test_blocked_goal_is_not_reachable():
    grid = GridMap(5, 5, blocked={(4, 4)})
    assert not grid.find_path((0, 0), (4, 4)).found


def test_goal_outside_grid_and_start_outside_grid():
    grid = GridMap(5, 5)
    assert not grid.find_path((0, 0), (9, 9)).found
    assert not grid.find_path((-1, 0), (2, 2)).found


def test_no_diagonal_squeeze_between_blocked_cells():
    # Cells touch only diagonally, so a 4-connected robot must not pass.
    grid = GridMap.from_ascii([
        ".#.",
        "#.#",
        ".#.",
    ])
    assert not grid.find_path((0, 0), (2, 2)).found


# ------------------------------------------------------ obstacle avoidance
def test_never_crosses_shelves_or_walls_in_warehouse_layout():
    grid = GridMap.from_ascii([
        "#########",
        "#..S.S..#",
        "#..S.S..#",
        "#.......#",
        "#########",
    ])
    res = grid.find_path((1, 1), (7, 1))
    assert res.found
    assert_valid_path(grid, res.path)


def test_replans_around_new_obstacle_on_current_route():
    grid = GridMap(7, 5)
    first = grid.find_path((0, 2), (6, 2))
    assert first.cost == 6
    blocker = first.path[3]                       # appears on the planned route
    second = grid.find_path(first.path[2], (6, 2), extra_blocked={blocker})
    assert second.found
    assert blocker not in second.path
    assert_valid_path(grid, second.path)
    assert second.cost > 4  # a detour is longer than the straight line


def test_blocking_the_only_corridor_makes_goal_unreachable():
    grid = GridMap.from_ascii([
        "#####",
        "...#.",
        "#####",
    ])
    assert not grid.find_path((0, 1), (4, 1)).found
    open_grid = GridMap.from_ascii([
        "#####",
        ".....",
        "#####",
    ])
    assert open_grid.find_path((0, 1), (4, 1)).found
    assert not open_grid.find_path((0, 1), (4, 1), extra_blocked={(2, 1)}).found


# ------------------------------------------------------- optimality sweep
@pytest.mark.parametrize("seed", range(25))
def test_matches_bfs_on_random_grids(seed):
    rng = random.Random(seed)
    w, h = 14, 11
    blocked = {(x, y) for x in range(w) for y in range(h) if rng.random() < 0.28}
    grid = GridMap(w, h, blocked)
    free = [(x, y) for x in range(w) for y in range(h) if (x, y) not in blocked]
    if len(free) < 2:
        return
    start, goal = rng.sample(free, 2)
    res = grid.find_path(start, goal)
    ref = bfs_cost(grid, start, goal)
    if ref is None:
        assert not res.found
    else:
        assert res.found and res.cost == ref
        assert_valid_path(grid, res.path)
