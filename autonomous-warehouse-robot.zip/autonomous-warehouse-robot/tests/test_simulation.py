"""Obstacle avoidance, operator controls, reset, recognition and config tests."""
import copy
import json
from pathlib import Path

import pytest

from src.config import ConfigError, load_config, validate_config
from src.obstacle_avoidance import CollisionAvoidance, ObstacleMemory, ProximitySensorArray
from src.package_manager import PackageStatus
from src.recognition import OPENCV_AVAILABLE
from src.robot import RobotState
from src.simulation import Simulation
from src.warehouse import Warehouse

CONFIG = Path(__file__).resolve().parent.parent / "config" / "warehouse.json"


@pytest.fixture
def raw():
    return json.loads(CONFIG.read_text())


@pytest.fixture
def quiet(raw):
    cfg = copy.deepcopy(raw)
    cfg["movable_obstacles"] = []
    return cfg


# ------------------------------------------------------------- sensors
def test_sensors_distinguish_static_and_movable(raw):
    cfg = validate_config(raw)
    wh = Warehouse(cfg)
    sensors = ProximitySensorArray(wh, 3)
    # (1,3) heading north: free (1,2), then (1,1)=charger is free, then wall at (1,0)
    r = sensors.scan((1, 3), (0, -1))["front"]
    assert r.distance == 3 and r.obstacle.kind == "wall" and not r.obstacle.movable
    # right of a south-facing robot at (1,3) is west (0,3) wall -> look east instead (shelf)
    east = sensors.scan((1, 3), (0, -1))["right"]
    assert east.obstacle.kind == "shelf" and east.distance == 1
    # crate at (1,5) is movable and seen from (1,3) heading south at distance 2
    r = sensors.scan((1, 3), (0, 1))["front"]
    assert r.distance == 2 and r.obstacle.kind == "crate" and r.obstacle.movable
    assert r.obstacle.id == "CRATE-1"


def test_obstacle_memory_expires_and_forgets():
    mem = ObstacleMemory(ttl=5.0)
    mem.add((2, 2), now=10.0)
    assert mem.active(12.0) == {(2, 2)}
    assert mem.active(15.1) == set()
    mem.add((3, 3), now=0.0)
    mem.forget((3, 3))
    assert mem.active(1.0) == set()


def test_avoidance_only_blocks_when_obstacle_is_on_route(raw):
    cfg = validate_config(raw)
    wh = Warehouse(cfg)
    sensors = ProximitySensorArray(wh, 3)
    avoid = CollisionAvoidance(ObstacleMemory(5))
    readings = sensors.scan((1, 3), (0, 1))                 # crate 2 cells ahead
    on_route = [(1, 4), (1, 5), (1, 6)]
    off_route = [(1, 4)]
    d = avoid.assess(readings, on_route)
    assert d.blocked and d.obstacle_id == "CRATE-1" and d.movable and d.distance == 2
    assert not avoid.assess(readings, off_route).blocked


def test_robot_replans_around_crate_and_still_delivers(raw):
    cfg = copy.deepcopy(raw)
    cfg["movable_obstacles"] = [{"id": "CRATE-X", "kind": "crate", "cell": [1, 6]}]
    sim = Simulation(cfg)
    sim.add_task("PKG-005", "D1")        # shortest route runs down the x=1 aisle
    assert sim.run_until_idle(max_time=300)
    m = sim.metrics
    assert m.tasks_completed == 1
    assert m.obstacles_encountered >= 1 and m.movable_encounters >= 1
    assert m.replans >= 1 and m.plans_computed > m.replans
    assert m.collisions == 0


def test_no_collisions_with_patrolling_carts(raw):
    sim = Simulation(raw)
    sim.add_demo_tasks()
    assert sim.run_until_idle(max_time=900)
    assert sim.metrics.collisions == 0
    assert sim.metrics.tasks_completed == 4


def test_user_crate_toggle_rules(quiet):
    sim = Simulation(quiet)
    assert "placed" in sim.toggle_crate((5, 5))
    assert "removed" in sim.toggle_crate((5, 5))
    assert "Cannot" in sim.toggle_crate((3, 3))                 # shelf
    assert "charger" in sim.toggle_crate(sim.robot.cell).lower()  # charger cell is protected
    sim.robot.cell = (5, 5)
    assert "robot" in sim.toggle_crate((5, 5))                  # robot's own cell
    assert "outside" in sim.toggle_crate((99, 99))


def test_cart_never_enters_robot_cells(raw):
    sim = Simulation(raw)
    sim.add_demo_tasks()
    sim.start()
    for _ in range(int(240 / 0.05)):
        sim.update(0.05)
        robot_cells = sim.robot.occupied_cells()
        for o in sim.warehouse.obstacles:
            assert not (robot_cells & o.occupied_cells())


# ------------------------------------------------------------- controls
def test_pause_freezes_and_resume_continues(quiet):
    sim = Simulation(quiet)
    sim.add_task("PKG-001", "D1")
    sim.start()
    sim.update(5.0)
    sim.pause()
    snap = (sim.time, sim.robot.float_pos(), sim.robot.state, sim.metrics.distance_cells)
    sim.update(5.0)
    assert (sim.time, sim.robot.float_pos(), sim.robot.state, sim.metrics.distance_cells) == snap
    sim.resume()
    sim.update(2.0)
    assert sim.time > snap[0]


def test_emergency_stop_freezes_robot_and_resume_releases(quiet):
    sim = Simulation(quiet)
    sim.add_task("PKG-004", "D3")
    sim.start()
    sim.update(6.0)
    assert sim.robot.state is RobotState.MOVING
    sim.emergency_stop()
    assert sim.robot.state is RobotState.ERROR and sim.robot.estopped
    frozen = (sim.robot.float_pos(), sim.metrics.distance_cells, sim.robot.battery)
    sim.update(5.0)
    assert (sim.robot.float_pos(), sim.metrics.distance_cells, sim.robot.battery) == frozen
    assert "released" in sim.resume()
    assert sim.run_until_idle(max_time=300)
    assert sim.metrics.tasks_completed == 1


def test_start_refused_while_estopped(quiet):
    sim = Simulation(quiet)
    sim.emergency_stop()
    assert "halted" in sim.start()
    assert not sim.running


def test_reset_restores_clean_initial_state(raw):
    fresh = Simulation(raw).snapshot()
    sim = Simulation(raw)
    sim.add_demo_tasks()
    sim.toggle_crate((5, 5))
    sim.run_until_idle(max_time=40) or sim.update(1)
    sim.update(30)
    sim.emergency_stop()
    assert sim.snapshot() != fresh
    sim.reset()
    assert sim.snapshot() == fresh
    assert sim.robot.state is RobotState.IDLE and not sim.robot.estopped
    assert all(p.status is PackageStatus.STORED for p in sim.packages.all())
    assert sim.metrics.tasks_completed == 0 and sim.metrics.distance_cells == 0


def test_return_to_charger_command(quiet):
    sim = Simulation(quiet)
    sim.add_task("PKG-001", "D1")
    sim.run_until_idle(max_time=200)
    assert sim.robot.cell == sim.warehouse.charger
    assert sim.go_to_charger().startswith("Heading")                   # already home: no-op OK
    sim.robot.cell = (10, 5)
    sim.robot.heading_deg = 0.0
    assert sim.go_to_charger().startswith("Heading")
    sim.update(20)
    assert sim.robot.cell == sim.warehouse.charger


# ---------------------------------------------------------- recognition
@pytest.mark.parametrize("mode", ["sensor", "opencv"])
def test_recognition_identifies_every_package(raw, mode):
    if mode == "opencv" and not OPENCV_AVAILABLE:
        pytest.skip("OpenCV not installed")
    sim = Simulation(raw)
    rec = sim.recognizers[mode]
    for p in sim.packages.all():
        d = rec.recognize(p, p.home_cell, 1)
        assert d.package_id == p.id and d.category == p.category
        assert d.confidence is not None and 0.5 < d.confidence <= 1.0


@pytest.mark.parametrize("mode", ["sensor", "opencv"])
def test_no_package_gives_no_confidence(raw, mode):
    if mode == "opencv" and not OPENCV_AVAILABLE:
        pytest.skip("OpenCV not installed")
    d = Simulation(raw).recognizers[mode].recognize(None, (0, 0), 1)
    assert d.package_id is None and d.confidence is None


def test_confidence_is_computed_not_constant(raw):
    sim = Simulation(raw)
    rec = sim.recognizers["sensor"]
    confs = {round(rec.recognize(p, p.home_cell, 1).confidence, 4) for p in sim.packages.all()}
    assert len(confs) > 3
    # more noise -> lower measured confidence on average
    noisy = copy.deepcopy(raw)
    noisy["recognition"]["noise_sigma"] = 30.0
    rec2 = Simulation(noisy).recognizers["sensor"]
    avg = lambda r: sum(r.recognize(p, p.home_cell, 1).confidence for p in sim.packages.all())
    assert avg(rec2) < avg(rec)


@pytest.mark.skipif(not OPENCV_AVAILABLE, reason="OpenCV not installed")
def test_opencv_mode_end_to_end(quiet):
    quiet["recognition"]["mode"] = "opencv"
    sim = Simulation(quiet)
    assert sim.recognition_mode == "opencv"
    sim.add_task("PKG-003", "D2")
    assert sim.run_until_idle(max_time=300)
    assert sim.metrics.tasks_completed == 1
    assert any("[opencv]" in e.text for e in sim.log.entries)


# --------------------------------------------------------------- config
def test_missing_config_file_gives_clear_error(tmp_path):
    with pytest.raises(ConfigError, match="not found"):
        load_config(tmp_path / "nope.json")


def test_invalid_json_gives_clear_error(tmp_path):
    p = tmp_path / "bad.json"
    p.write_text("{ not json")
    with pytest.raises(ConfigError, match="Invalid JSON"):
        load_config(p)


def _mutated(raw, fn):
    cfg = copy.deepcopy(raw)
    fn(cfg)
    return cfg


@pytest.mark.parametrize("mutate,match", [
    (lambda c: c["layout"].__setitem__(3, "short"), "same, non-zero length"),
    (lambda c: c["layout"].__setitem__(2, "#" + "?" * 24 + "#"), "unknown character"),
    (lambda c: c["packages"][0].__setitem__("cell", [2, 2]), "shelf"),
    (lambda c: c["packages"][1].__setitem__("id", "PKG-001"), "duplicate"),
    (lambda c: c["packages"][0].__setitem__("category", "ghost"), "category"),
    (lambda c: c["delivery_points"].__setitem__("D1", [1, 1]), "'D' cell"),
    (lambda c: c["robot"].__setitem__("speed_cells_per_s", -1), "speed_cells_per_s"),
    (lambda c: c["movable_obstacles"][0].__setitem__("patrol", [[1, 8], [3, 9]]), "share a row"),
    (lambda c: c["demo_tasks"].append({"package": "PKG-404", "destination": "D1"}), "demo_tasks"),
])
def test_invalid_configs_rejected(raw, mutate, match):
    with pytest.raises(ConfigError, match=match):
        validate_config(_mutated(raw, mutate))


def test_layout_without_charger_rejected(raw):
    cfg = copy.deepcopy(raw)
    cfg["layout"] = [r.replace("C", ".") for r in cfg["layout"]]
    with pytest.raises(ConfigError, match="charging station"):
        validate_config(cfg)


def test_alternative_layout_runs(quiet):
    """The simulator is layout-agnostic: a tiny custom warehouse works."""
    cfg = {
        "layout": ["#######", "#C.PS.#", "#.....#", "#..D..#", "#######"],
        "categories": {"a": {"color": [200, 40, 40]}, "b": {"color": [40, 200, 40]}},
        "packages": [{"id": "PKG-001", "category": "a", "cell": [4, 1]},
                     {"id": "PKG-002", "category": "b", "cell": [3, 1]}],
        "delivery_points": {"D1": [3, 3]},
    }
    sim = Simulation(cfg)
    assert sim.add_task("PKG-001", "D1").ok
    assert sim.run_until_idle(max_time=120)
    assert sim.metrics.tasks_completed == 1
