"""Headless UI tests: render frames and operate every control with real pygame events."""
import os

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import json
from pathlib import Path

import pygame
import pytest

from src.package_manager import PackageStatus
from src.robot import RobotState
from src.simulation import Simulation
from src.ui import App

CONFIG = Path(__file__).resolve().parent.parent / "config" / "warehouse.json"


@pytest.fixture
def app():
    a = App(Simulation(json.loads(CONFIG.read_text())))
    yield a
    pygame.quit()


def click(app, rect_center):
    pos = tuple(int(v) for v in rect_center)
    app.handle_event(pygame.event.Event(pygame.MOUSEBUTTONDOWN, button=1, pos=pos))


def press(app, key, unicode=""):
    app.handle_event(pygame.event.Event(pygame.KEYDOWN, key=key, unicode=unicode, mod=0))


def button(app, label_start):
    for b in app.buttons:
        text = b.label_fn() if b.label_fn else b.label
        if text.startswith(label_start):
            return b
    raise AssertionError(f"no button {label_start!r}")


def advance(app, seconds, fps=30):
    for _ in range(int(seconds * fps)):
        app.sim.update(1.0 / fps * app.SPEEDS[app.speed_idx])
        app.render()


def test_renders_all_panels_without_error(app):
    app.render()
    assert app.screen.get_size() == (1280, 720)
    # canvas and right-hand panels actually drew something
    assert app.screen.get_at((app.ox + 5, app.oy + 5)) != (18, 20, 26, 255)


def test_task_creation_via_text_input_and_validation_messages(app):
    app.pkg_input.focused = True
    app.pkg_input.text = ""
    for ch in "pkg-777":
        press(app, ord(ch), ch)
    assert app.pkg_input.text == "PKG-777"
    press(app, pygame.K_RETURN)                       # Enter submits
    assert "Invalid package ID" in app.message[0]
    assert len(app.sim.tasks.queue) == 0
    app.pkg_input.text = "PKG-003"
    click(app, button(app, "ADD TASK").rect.center)
    assert "queued" in app.message[0] and len(app.sim.tasks.queue) == 1
    click(app, button(app, "ADD TASK").rect.center)   # same package again
    assert "already assigned" in app.message[0]
    app.dest_input.text = "D7"
    app.pkg_input.text = "PKG-002"
    click(app, button(app, "ADD TASK").rect.center)
    assert "Unknown destination" in app.message[0]


def test_cycle_buttons_fill_inputs(app):
    app.pkg_input.text = ""
    click(app, (app.r_task.x + 196, app.r_task.y + 38))
    assert app.pkg_input.text == "PKG-001"
    click(app, (app.r_task.x + 306, app.r_task.y + 38))
    assert app.dest_input.text in app.sim.warehouse.delivery_points


def test_start_pause_resume_buttons(app):
    click(app, button(app, "DEMO TASKS").rect.center)
    assert len(app.sim.tasks.queue) == 4
    click(app, button(app, "START").rect.center)
    assert app.sim.running
    advance(app, 3)
    pos = app.sim.robot.float_pos()
    click(app, button(app, "PAUSE").rect.center)
    assert app.sim.paused
    advance(app, 2)
    assert app.sim.robot.float_pos() == pos           # frozen
    click(app, button(app, "RESUME").rect.center)
    assert not app.sim.paused
    advance(app, 2)
    assert app.sim.robot.float_pos() != pos           # moving again


def test_emergency_stop_and_release_via_buttons_and_keys(app):
    app.sim.add_task("PKG-004", "D3")
    press(app, pygame.K_s)
    advance(app, 4)
    press(app, pygame.K_SPACE)                        # keyboard e-stop
    assert app.sim.robot.estopped and app.sim.robot.state is RobotState.ERROR
    pos = app.sim.robot.float_pos()
    advance(app, 2)
    assert app.sim.robot.float_pos() == pos
    click(app, button(app, "RESUME").rect.center)     # releases e-stop
    assert not app.sim.robot.estopped
    click(app, button(app, "EMERGENCY").rect.center)  # on-screen e-stop
    assert app.sim.robot.estopped


def test_reset_button_restores_initial_state(app):
    click(app, button(app, "DEMO TASKS").rect.center)
    click(app, button(app, "START").rect.center)
    advance(app, 8)
    assert app.sim.robot.cell != app.sim.warehouse.start or app.sim.metrics.distance_cells > 0
    click(app, button(app, "RESET").rect.center)
    s = app.sim
    assert s.robot.cell == s.warehouse.start and s.metrics.distance_cells == 0
    assert not s.running and len(s.tasks.queue) == 0 and s.time == 0
    assert all(p.status is PackageStatus.STORED for p in s.packages.all())
    app.render()                                      # UI still renders after the rebuild


def test_toggles_speed_and_recognition_mode(app):
    click(app, button(app, "Explored").rect.center)
    assert app.show_explored is False
    click(app, button(app, "Sensors").rect.center)
    assert app.show_sensors is False
    click(app, button(app, "Speed").rect.center)
    assert app.SPEEDS[app.speed_idx] == 2
    click(app, button(app, "Rec:").rect.center)
    assert app.sim.recognition_mode == "opencv"
    click(app, button(app, "Rec:").rect.center)
    assert app.sim.recognition_mode == "sensor"


def test_clicking_canvas_toggles_crate(app):
    cx, cy = app.cell_rect(6, 5).center
    n = len(app.sim.warehouse.obstacles)
    click(app, (cx, cy))
    assert len(app.sim.warehouse.obstacles) == n + 1
    click(app, (cx, cy))
    assert len(app.sim.warehouse.obstacles) == n
    sx, sy = app.cell_rect(3, 3).center                 # shelf: refused
    click(app, (sx, sy))
    assert len(app.sim.warehouse.obstacles) == n


def test_full_demo_through_the_ui_and_all_panels_render_each_frame(app):
    press(app, pygame.K_d)
    press(app, pygame.K_s)
    press(app, pygame.K_4)                              # 8x
    states = set()
    for _ in range(60 * 60):                            # up to 60 s of wall time at 60 fps
        app.sim.update(1 / 60 * app.SPEEDS[app.speed_idx])
        if _ % 6 == 0:
            app.render()
        states.add(app.sim.robot.state)
        if app.sim.metrics.tasks_completed == 4:
            break
    assert app.sim.metrics.tasks_completed == 4 and app.sim.metrics.collisions == 0
    assert {RobotState.PLANNING, RobotState.MOVING, RobotState.PICKING,
            RobotState.DELIVERING} <= states


def test_opencv_thumbnail_renders(app):
    press(app, pygame.K_d)
    click(app, button(app, "Rec:").rect.center)
    press(app, pygame.K_s)
    for _ in range(60 * 40):
        app.sim.update(1 / 30 * 4)
        if app.sim.robot.target_detection is not None:
            break
    assert app.sim.robot.target_detection.frame is not None
    app.render()


def test_ui_survives_missing_system_fonts(monkeypatch):
    """Font lookup failures must fall back to pygame's built-in font, not crash."""
    def boom(*a, **k):
        raise OSError("no such font")
    monkeypatch.setattr(pygame.font, "SysFont", boom)
    a = App(Simulation(json.loads(CONFIG.read_text())))
    a.render()
    pygame.quit()
