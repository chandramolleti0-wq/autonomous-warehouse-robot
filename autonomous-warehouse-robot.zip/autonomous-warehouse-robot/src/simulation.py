"""Simulation orchestrator: owns all components and the operator controls."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from .config import load_config, validate_config
from .metrics import EventLog, Metrics
from .obstacle_avoidance import CollisionAvoidance, ObstacleMemory, ProximitySensorArray
from .package_manager import PackageManager
from .recognition import OPENCV_AVAILABLE, make_recognizers
from .robot import Robot, RobotContext, RobotState
from .task_manager import SubmitResult, TaskManager
from .warehouse import Warehouse

Cell = tuple[int, int]
MAX_SUBSTEP = 1.0 / 30.0


class Simulation:
    def __init__(self, config: dict):
        self.config = validate_config(config)
        self._build()

    @classmethod
    def from_file(cls, path: str | Path) -> "Simulation":
        return cls(load_config(path))

    # ------------------------------------------------------------- build
    def _build(self) -> None:
        cfg = self.config
        rc = cfg["robot"]
        self.time = 0.0
        self.running = False
        self.paused = False
        self.log = EventLog()
        self.metrics = Metrics(cell_size_m=cfg["cell_size_m"])
        self.warehouse = Warehouse(cfg)
        self.packages = PackageManager(self.warehouse, cfg)
        self.tasks = TaskManager(self.warehouse, self.packages)
        self.sensors = ProximitySensorArray(self.warehouse, rc["sensor_range_cells"])
        self.memory = ObstacleMemory(rc["obstacle_memory_s"])
        self.avoidance = CollisionAvoidance(self.memory)
        rec = cfg["recognition"]
        self.recognizers = make_recognizers(self.packages.categories, self.packages.by_number(),
                                            rec["noise_sigma"], rec["seed"])
        self.recognition_mode = rec["mode"]
        if self.recognition_mode not in self.recognizers:
            self.log.add("WARN", 0.0, "OpenCV unavailable - using simulated sensor recognition")
            self.recognition_mode = "sensor"
        ctx = RobotContext(self.warehouse, self.packages, self.tasks, self.metrics, self.log,
                           self.sensors, self.avoidance, self.memory,
                           clock=lambda: self.time, is_running=lambda: self.running,
                           get_recognizer=lambda: self.recognizers[self.recognition_mode],
                           min_confidence=rec["min_confidence"])
        self.robot = Robot(ctx, cfg)
        self.log.add("INFO", 0.0, f"Loaded '{self.warehouse.name}' "
                                  f"({self.warehouse.width}x{self.warehouse.height}, "
                                  f"{len(self.packages.all())} packages)")

    # --------------------------------------------------------- controls
    def start(self) -> str:
        if self.robot.latched or self.robot.estopped:
            return "Robot is halted - Reset (or release the e-stop) first"
        if self.paused:
            return "Simulation is paused - press Resume"
        self.running = True
        if self.tasks.has_queued():
            self.log.add("INFO", self.time, "Start: processing task queue")
            return "Started"
        self.log.add("INFO", self.time, "Start pressed with an empty queue")
        return "Started - queue is empty, add a task"

    def pause(self) -> str:
        if self.paused:
            return "Already paused"
        self.paused = True
        self.log.add("INFO", self.time, "Simulation paused")
        return "Paused"

    def resume(self) -> str:
        if self.robot.estopped:
            self.robot.release_estop()
            return "Emergency stop released"
        if self.paused:
            self.paused = False
            self.log.add("INFO", self.time, "Simulation resumed")
            return "Resumed"
        return "Nothing to resume"

    def emergency_stop(self) -> str:
        self.robot.emergency_stop()
        return "EMERGENCY STOP"

    def reset(self) -> str:
        mode = self.recognition_mode
        self._build()
        if mode in self.recognizers:
            self.recognition_mode = mode
        self.log.add("INFO", 0.0, "Simulation reset to initial state")
        return "Simulation reset"

    def go_to_charger(self) -> str:
        if self.robot.go_to_charger():
            self.running = True
            return "Heading to charging station"
        return "Cannot send to charger while a task is active or robot is halted"

    def set_recognition_mode(self, mode: str) -> str:
        if mode not in self.recognizers:
            return "OpenCV recognition unavailable (install opencv-python)"
        self.recognition_mode = mode
        self.log.add("INFO", self.time, f"Recognition mode: {mode}")
        return f"Recognition: {mode}"

    # ------------------------------------------------------------ tasks
    def add_task(self, package_id: str, destination: str) -> SubmitResult:
        res = self.tasks.submit(package_id, destination, self.robot.cell, self.time)
        self.log.add("SUCCESS" if res.ok else "WARN", self.time,
                     res.message if res.ok else f"Task rejected: {res.message}")
        return res

    def add_demo_tasks(self) -> str:
        added = 0
        for t in self.config["demo_tasks"]:
            if self.add_task(t["package"], t["destination"]).ok:
                added += 1
        return f"{added} demo task(s) queued"

    def toggle_crate(self, cell: Cell) -> str:
        ok, msg = self.warehouse.toggle_crate(cell, self.robot.occupied_cells())
        self.log.add("INFO" if ok else "WARN", self.time, msg)
        return msg

    # ------------------------------------------------------------ update
    def update(self, dt: float) -> None:
        """Advance the world by ``dt`` seconds (split into small sub-steps)."""
        if self.paused:
            return
        remaining = dt
        while remaining > 1e-9:
            step = min(remaining, MAX_SUBSTEP)
            remaining -= step
            self.time += step
            self.warehouse.update_obstacles(step, self.robot.occupied_cells())
            self.robot.update(step)
            self._check_collisions()

    def _check_collisions(self) -> None:
        """Independent safety monitor: counts any overlap with a movable obstacle."""
        cells = self.robot.occupied_cells()
        for o in self.warehouse.obstacles:
            if cells & o.occupied_cells():
                self.metrics.collisions += 1
                self.log.add("ERROR", self.time, f"COLLISION with {o.id}!")

    def run_until_idle(self, max_time: float = 600.0, dt: float = 0.05) -> bool:
        """Headless helper: run until the queue is empty and the robot rests."""
        self.start()
        t_end = self.time + max_time
        while self.time < t_end:
            self.update(dt)
            r = self.robot
            if (not self.tasks.has_queued() and r.task is None
                    and r.state in (RobotState.IDLE, RobotState.ERROR)
                    and (r.latched or r.cell == self.warehouse.charger
                         and r.battery >= r.bc["capacity"] - 1e-6)):
                return True
        return False

    def snapshot(self) -> dict:
        """Compact state summary (used by reset tests)."""
        m = self.metrics
        return {
            "time": round(self.time, 6), "running": self.running, "paused": self.paused,
            "cell": self.robot.cell, "state": self.robot.state, "battery": self.robot.battery,
            "queue": len(self.tasks.queue), "history": len(self.tasks.history),
            "packages": {p.id: p.status for p in self.packages.all()},
            "obstacles": sorted((o.id, o.cell) for o in self.warehouse.obstacles),
            "metrics": (m.distance_cells, m.obstacles_encountered, m.replans, m.plans_computed,
                        m.tasks_completed, m.tasks_failed, m.energy_used, m.collisions),
        }
