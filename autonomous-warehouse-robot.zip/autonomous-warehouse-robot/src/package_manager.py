"""Package inventory and lifecycle: STORED -> ASSIGNED -> CARRIED -> DELIVERED."""
from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from .warehouse import Warehouse

Cell = tuple[int, int]


class PackageStatus(Enum):
    STORED = "STORED"
    ASSIGNED = "ASSIGNED"
    CARRIED = "CARRIED"
    DELIVERED = "DELIVERED"


@dataclass
class Package:
    id: str
    category: str
    color: tuple[int, int, int]
    home_cell: Cell
    status: PackageStatus = PackageStatus.STORED
    task_id: Optional[int] = None
    delivered_cell: Optional[Cell] = None

    @property
    def number(self) -> int:
        """Numeric part of the ID (this is what the visual label encodes)."""
        return int(re.search(r"(\d+)$", self.id).group(1))  # type: ignore[union-attr]


class PackageManager:
    def __init__(self, warehouse: Warehouse, cfg: dict):
        self.warehouse = warehouse
        self.categories = {n: tuple(s["color"]) for n, s in cfg["categories"].items()}
        self._packages: dict[str, Package] = {}
        for p in cfg["packages"]:
            pkg = Package(p["id"], p["category"], self.categories[p["category"]], tuple(p["cell"]))
            self._packages[pkg.id] = pkg
            warehouse.package_at[pkg.home_cell] = pkg.id

    # ------------------------------------------------------------ lookups
    def get(self, package_id: str) -> Optional[Package]:
        return self._packages.get(str(package_id).strip().upper())

    def all(self) -> list[Package]:
        return sorted(self._packages.values(), key=lambda p: p.number)

    def by_number(self) -> dict[int, str]:
        return {p.number: p.id for p in self._packages.values()}

    def access_cells(self, package_id: str) -> list[Cell]:
        """Free cells (per the known map) from which the package can be picked."""
        pkg = self._packages[package_id]
        return [n for n in self.warehouse.neighbours4(pkg.home_cell)
                if not self.warehouse.is_map_blocked(n)]

    # --------------------------------------------------------- transitions
    def assign(self, package_id: str, task_id: int) -> None:
        pkg = self._packages[package_id]
        if pkg.status is not PackageStatus.STORED:
            raise ValueError(f"{package_id} is {pkg.status.value}, cannot be assigned")
        pkg.status, pkg.task_id = PackageStatus.ASSIGNED, task_id

    def release(self, package_id: str) -> None:
        """ASSIGNED -> STORED (task failed before pickup)."""
        pkg = self._packages[package_id]
        if pkg.status is PackageStatus.ASSIGNED:
            pkg.status, pkg.task_id = PackageStatus.STORED, None

    def pickup(self, package_id: str) -> None:
        pkg = self._packages[package_id]
        if pkg.status is not PackageStatus.ASSIGNED:
            raise ValueError(f"{package_id} is {pkg.status.value}, cannot be picked up")
        pkg.status = PackageStatus.CARRIED
        self.warehouse.package_at.pop(pkg.home_cell, None)

    def place(self, package_id: str, cell: Cell) -> None:
        pkg = self._packages[package_id]
        if pkg.status is not PackageStatus.CARRIED:
            raise ValueError(f"{package_id} is {pkg.status.value}, cannot be placed")
        pkg.status, pkg.delivered_cell = PackageStatus.DELIVERED, cell

    def delivered_at(self, cell: Cell) -> list[Package]:
        return [p for p in self._packages.values()
                if p.status is PackageStatus.DELIVERED and p.delivered_cell == cell]
