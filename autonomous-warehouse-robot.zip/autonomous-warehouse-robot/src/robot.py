"""Autonomous robot: kinematics, battery and the pick-and-place state machine.

States
------
IDLE        waiting for work
PLANNING    A* search running / displaying; also "waiting for route to clear"
MOVING      driving to a package (or to the charger)
PICKING     scanning neighbours, identifying the package, grasping it
DELIVERING  transporting the package to the delivery cell and placing it
COMPLETED   task just finished (shown briefly)
ERROR       task failed / emergency stop / battery depleted
CHARGING    on the charging station (extension beyond the 7 required states)

Workflow per task
-----------------
receive task -> locate package -> plan to pickup -> navigate (sense, stop,
replan) -> stop at pickup cell -> scan & identify -> grasp -> plan to
destination -> navigate -> place -> record result.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Optional

from .metrics import EventLog, Metrics
from .obstacle_avoidance import (AvoidanceDecision, CollisionAvoidance,
                                 ObstacleMemory, ProximitySensorArray, SensorReading)
from .package_manager import Package, PackageManager, PackageStatus
from .path_planning import astar
from .recognition import Detection
from .task_manager import Task, TaskManager
from .warehouse import Warehouse

Cell = tuple[int, int]
DIR_TO_ANGLE = {(1, 0): 0.0, (0, 1): 90.0, (-1, 0): 180.0, (0, -1): 270.0}
ANGLE_TO_DIR = {v: k for k, v in DIR_TO_ANGLE.items()}


class RobotState(Enum):
    IDLE = "IDLE"
    PLANNING = "PLANNING"
    MOVING = "MOVING"
    PICKING = "PICKING"
    DELIVERING = "DELIVERING"
    COMPLETED = "COMPLETED"
    ERROR = "ERROR"
    CHARGING = "CHARGING"


@dataclass
class RobotContext:
    """Everything the robot needs from the rest of the simulation."""
    warehouse: Warehouse
    packages: PackageManager
    tasks: TaskManager
    metrics: Metrics
    log: EventLog
    sensors: ProximitySensorArray
    avoidance: CollisionAvoidance
    memory: ObstacleMemory
    clock: Callable[[], float]
    is_running: Callable[[], bool]
    get_recognizer: Callable[[], Any]
    min_confidence: float


class Robot:
    def __init__(self, ctx: RobotContext, cfg: dict):
        self.ctx = ctx
        rc = cfg["robot"]
        bc = rc["battery"]
        self.rc, self.bc = rc, bc
        self.speed = rc["speed_cells_per_s"]
        self.turn_rate = rc["turn_rate_deg_s"]

        self.cell: Cell = ctx.warehouse.start
        self.heading_deg = 90.0
        self.moving_to: Optional[Cell] = None
        self.progress = 0.0
        self.battery: float = bc["capacity"]
        self.carrying: Optional[str] = None

        self.state = RobotState.IDLE
        self.phase = "idle"
        self.task: Optional[Task] = None
        self.package: Optional[Package] = None
        self.mission: Optional[str] = None      # pickup | delivery | charge | return
        self.nav_state = RobotState.MOVING
        self.sub: Optional[str] = None
        self.timer = 0.0
        self.latched = False
        self.estopped = False
        self._saved_state = RobotState.IDLE
        self.error_message = ""

        self.path: list[Cell] = []
        self.path_index = 0
        self.explored: list[Cell] = []
        self.goals: set[Cell] = set()
        self.plan_progress = 1.0
        self.readings: dict[str, SensorReading] = {}
        self.detections: list[Detection] = []
        self.target_detection: Optional[Detection] = None

        self._plan_result = None
        self._plan_reason = "initial"
        self._plan_phase = "computing"          # computing | waiting
        self._wait = 0.0
        self._retry = 0.0
        self._target_cell: Optional[Cell] = None
        self._last_encounter: dict[str, float] = {}
        self._low_battery_warned = False
        self._return_cooldown = 0.0
        self._task_replans = 0

    # ------------------------------------------------------------ helpers
    @property
    def now(self) -> float:
        return self.ctx.clock()

    def _log(self, level: str, text: str) -> None:
        self.ctx.log.add(level, self.now, text)

    def occupied_cells(self) -> set[Cell]:
        cells = {self.cell}
        if self.moving_to is not None:
            cells.add(self.moving_to)
        return cells

    def float_pos(self) -> tuple[float, float]:
        if self.moving_to is None:
            return (float(self.cell[0]), float(self.cell[1]))
        return (self.cell[0] + (self.moving_to[0] - self.cell[0]) * self.progress,
                self.cell[1] + (self.moving_to[1] - self.cell[1]) * self.progress)

    def heading_dir(self) -> Cell:
        return ANGLE_TO_DIR[(round(self.heading_deg / 90.0) % 4) * 90.0]

    def _set_state(self, state: RobotState, phase: str) -> None:
        self.state, self.phase = state, phase

    def _turn_to(self, angle: float, dt: float) -> bool:
        diff = (angle - self.heading_deg + 180.0) % 360.0 - 180.0
        step = self.turn_rate * dt
        if abs(diff) <= step:
            self.heading_deg = angle % 360.0
            return True
        self.heading_deg = (self.heading_deg + math.copysign(step, diff)) % 360.0
        return False

    def _passable_known(self, extra: set[Cell]):
        wh = self.ctx.warehouse
        return lambda c: not wh.is_map_blocked(c) and c not in extra

    @property
    def battery_pct(self) -> float:
        return 100.0 * self.battery / self.bc["capacity"]

    @property
    def route_remaining(self) -> int:
        return max(0, len(self.path) - 1 - self.path_index)

    # ------------------------------------------------------------ energy
    def _consume(self, amount: float) -> None:
        if amount <= 0 or self.estopped:
            return
        self.battery = max(0.0, self.battery - amount)
        self.ctx.metrics.energy_used += amount
        if self.battery_pct < self.bc["low_battery_pct"] and not self._low_battery_warned:
            self._low_battery_warned = True
            self._log("WARN", f"Low battery: {self.battery_pct:.0f}%")
        if self.battery <= 0.0 and not self.latched:
            self._fatal("battery depleted")

    def _fatal(self, reason: str) -> None:
        self._log("ERROR", f"Fatal: {reason}")
        if self.task is not None:
            self._fail_task(reason, latch=True)
        else:
            self._set_state(RobotState.ERROR, reason)
            self.error_message, self.latched = reason, True

    # ---------------------------------------------------------- main loop
    def update(self, dt: float) -> None:
        self.readings = self.ctx.sensors.scan(self.cell, self.heading_dir())
        if self.estopped:
            return
        self._return_cooldown = max(0.0, self._return_cooldown - dt)
        s = self.state
        if s is RobotState.IDLE:
            self._update_idle(dt)
        elif s is RobotState.CHARGING:
            self._update_charging(dt)
        elif s is RobotState.PLANNING:
            self._update_planning(dt)
        elif s in (RobotState.MOVING, RobotState.DELIVERING):
            self._update_motion(dt)
        elif s is RobotState.PICKING:
            self._update_picking(dt)
        elif s is RobotState.COMPLETED:
            self.timer -= dt
            if self.timer <= 0:
                self._clear_task()
                self._set_state(RobotState.IDLE, "idle")
        elif s is RobotState.ERROR and not self.latched:
            self.timer -= dt
            if self.timer <= 0:
                self._clear_task()
                self._set_state(RobotState.IDLE, "idle")

    def _clear_task(self) -> None:
        self.task, self.package, self.mission, self.sub = None, None, None, None
        self.path, self.explored, self.goals = [], [], set()
        self.path_index = 0
        self.plan_progress = 1.0

    # ----------------------------------------------------------- idle
    def _update_idle(self, dt: float) -> None:
        wh, bc = self.ctx.warehouse, self.bc
        if self.ctx.is_running() and self.ctx.tasks.has_queued():
            self._start_next_task()
            return
        if self.cell == wh.charger and self.battery < bc["capacity"]:
            self._set_state(RobotState.CHARGING, "charging")
            return
        if self.cell != wh.charger:
            self._consume(bc["idle_drain_per_s"] * dt)
            if (self.ctx.is_running() and bc["auto_return_to_charger"]
                    and self._return_cooldown <= 0 and self.state is RobotState.IDLE):
                self.go_to_charger()

    def go_to_charger(self) -> bool:
        """Public: drive to the charging station (only when no task is active)."""
        if self.task is not None or self.latched or self.estopped:
            return False
        if self.cell == self.ctx.warehouse.charger:
            return True
        self.mission, self.nav_state = "return", RobotState.MOVING
        self.goals = {self.ctx.warehouse.charger}
        self._log("INFO", "Returning to charging station")
        self._begin_plan("initial")
        return True

    # ------------------------------------------------------- task start
    def _start_next_task(self) -> None:
        ctx = self.ctx
        self.task = ctx.tasks.start_next(self.now)
        self.package = ctx.packages.get(self.task.package_id)
        self._task_replans, self._wait = 0, 0.0
        self._log("INFO", f"Task {self.task.label()} received; locating {self.task.package_id} "
                          f"at {self.package.home_cell}")
        self._launch_task()

    def _estimate_energy(self) -> Optional[float]:
        """Energy for robot -> pickup -> destination -> charger on the known map."""
        wh, pkg, task = self.ctx.warehouse, self.package, self.task
        passable = self._passable_known(set())
        r1 = astar(wh.width, wh.height, passable, self.cell, self.ctx.packages.access_cells(pkg.id))
        if not r1.found:
            return None
        dest = wh.delivery_points[task.destination]
        r2 = astar(wh.width, wh.height, passable, r1.path[-1], {dest})
        if not r2.found:
            return None
        r3 = astar(wh.width, wh.height, passable, dest, {wh.charger})
        steps = r1.cost + r2.cost + (r3.cost if r3.found else 0)
        return steps * self.bc["energy_per_cell"] + 2 * self.bc["energy_per_action"] + self.bc["reserve"]

    def _launch_task(self) -> None:
        """Energy check, then either charge first or head for the package."""
        pkg, task, wh = self.package, self.task, self.ctx.warehouse
        if pkg.status is not PackageStatus.ASSIGNED:
            self._fail_task(f"{pkg.id} is {pkg.status.value}, cannot be picked up")
            return
        need = self._estimate_energy()
        if need is None:
            self._fail_task("destination or package unreachable")
            return
        if need > self.bc["capacity"]:
            self._fail_task(f"task needs {need:.0f} energy units, battery capacity is "
                            f"{self.bc['capacity']:.0f}")
            return
        if self.battery < need:
            self._log("WARN", f"Battery {self.battery:.1f} < {need:.1f} needed - charging first")
            self.mission, self.nav_state = "charge", RobotState.MOVING
            self.goals = {wh.charger}
            if self.cell == wh.charger:
                self._set_state(RobotState.CHARGING, "charging before task")
            else:
                self._begin_plan("initial")
            return
        self.mission, self.nav_state = "pickup", RobotState.MOVING
        self.goals = set(self.ctx.packages.access_cells(pkg.id))
        self._begin_plan("initial")

    # --------------------------------------------------------- charging
    def _update_charging(self, dt: float) -> None:
        bc = self.bc
        if (self.task is None and self.ctx.is_running() and self.ctx.tasks.has_queued()):
            self._start_next_task()   # may decide to keep charging first
            return
        self.battery = min(bc["capacity"], self.battery + bc["charge_rate_per_s"] * dt)
        if self.battery_pct >= self.bc["low_battery_pct"]:
            self._low_battery_warned = False
        if self.battery >= bc["capacity"]:
            if self.task is not None and self.mission == "charge":
                self._log("INFO", "Battery full - resuming task")
                if self.carrying:                       # was diverted while carrying
                    self.mission, self.nav_state = "delivery", RobotState.DELIVERING
                    self.goals = {self.ctx.warehouse.delivery_points[self.task.destination]}
                    self._begin_plan("initial")
                else:
                    self._launch_task()
            else:
                self._set_state(RobotState.IDLE, "idle (battery full)")

    # --------------------------------------------------------- planning
    def _begin_plan(self, reason: str) -> None:
        ctx = self.ctx
        wh = ctx.warehouse
        extra = ctx.memory.active(self.now)
        t0 = time.perf_counter()
        res = astar(wh.width, wh.height, self._passable_known(extra), self.cell, self.goals)
        ms = (time.perf_counter() - t0) * 1000.0
        ctx.metrics.record_plan(res.nodes_expanded, ms, replan=(reason == "blocked"))
        self._plan_result, self._plan_reason, self._plan_phase = res, reason, "computing"
        self.explored = res.explored
        self.path, self.path_index = [], 0
        self.plan_progress = 0.0
        self.timer = self.rc["retry_plan_s"] if reason == "retry" else self.rc["plan_display_s"]
        target = {"pickup": "pickup", "delivery": "delivery", "charge": "charger",
                  "return": "charger"}.get(self.mission or "", "goal")
        self._set_state(RobotState.PLANNING, f"planning route to {target} ({reason})")
        if res.found:
            self._log("INFO", f"A* ({reason}): {res.cost} steps, {res.nodes_expanded} nodes "
                              f"expanded, {ms:.2f} ms")
        elif reason != "retry":
            self._log("WARN", f"A* ({reason}): no route found "
                              f"({res.nodes_expanded} nodes expanded)")

    def _update_planning(self, dt: float) -> None:
        if self._plan_phase == "waiting":
            self._wait += dt
            self._retry -= dt
            if self._wait > self.rc["max_blocked_wait_s"]:
                self._navigation_failed("route blocked for too long")
            elif self._retry <= 0:
                self._begin_plan("retry")
            return
        self.timer -= dt
        denom = self.rc["retry_plan_s"] if self._plan_reason == "retry" else self.rc["plan_display_s"]
        self.plan_progress = min(1.0, 1.0 - max(0.0, self.timer) / denom)
        if self.timer > 0:
            return
        res = self._plan_result
        if res.found:
            self.path, self.path_index = list(res.path), 0
            label = {"pickup": "driving to pickup", "delivery": "delivering package",
                     "charge": "driving to charger", "return": "returning to charger"}
            self._set_state(self.nav_state, label.get(self.mission or "", "moving"))
            return
        if self.ctx.memory.active(self.now):
            if self._plan_reason != "retry":
                self._log("WARN", "No route while avoiding sensed obstacles - waiting for them to clear")
            self._plan_phase, self._retry = "waiting", self.rc["retry_interval_s"]
            self.phase = "waiting for route to clear"
        else:
            self._navigation_failed("destination unreachable")

    def _navigation_failed(self, reason: str) -> None:
        if self.task is not None:
            self._fail_task(reason)
        else:
            self._log("WARN", f"Cannot return to charger: {reason}")
            self._return_cooldown = 10.0
            self._clear_task()
            self._set_state(RobotState.IDLE, "idle")

    # ------------------------------------------------------- navigation
    def _update_motion(self, dt: float) -> None:
        if self.state is RobotState.DELIVERING and self.sub == "place":
            self.timer -= dt
            if self.timer <= 0:
                self._finish_place()
            return
        if self.moving_to is not None:
            self._advance(dt)
            return
        if self.path_index >= len(self.path) - 1:
            self._on_arrival()
            return
        if self._battery_guard():
            return
        nxt = self.path[self.path_index + 1]
        want = DIR_TO_ANGLE[(nxt[0] - self.cell[0], nxt[1] - self.cell[1])]
        if not self._turn_to(want, dt):
            return
        self.readings = self.ctx.sensors.scan(self.cell, self.heading_dir())
        decision = self.ctx.avoidance.assess(self.readings, self.path[self.path_index + 1:])
        if decision.blocked:
            self._on_blocked(decision)
            return
        if self.ctx.warehouse.is_physically_blocked(nxt):   # last-resort interlock
            occ = self.ctx.warehouse.occupant(nxt)
            self._on_blocked(AvoidanceDecision(True, nxt, occ.kind if occ else "unknown",
                                               occ.id if occ else None, 1,
                                               bool(occ and occ.movable)))
            return
        self.moving_to, self.progress = nxt, 0.0

    def _battery_guard(self) -> bool:
        """Divert to the charger if the task can no longer be finished on this charge.

        Uses lower-bound (Manhattan) leg estimates with a 30 % detour margin.
        Skipped when even the charger is out of reach - nothing would help then.
        """
        if self.mission not in ("pickup", "delivery") or self.task is None:
            return False
        if self.battery_pct > 50.0:                       # cheap pre-filter
            return False
        wh, e = self.ctx.warehouse, self.bc["energy_per_cell"]
        from .path_planning import manhattan
        end = self.path[-1]
        dest = wh.delivery_points[self.task.destination]
        if self.mission == "pickup":
            legs = self.route_remaining + manhattan(end, dest) + manhattan(dest, wh.charger)
            actions = 2
        else:
            legs = self.route_remaining + manhattan(end, wh.charger)
            actions = 1
        need = legs * e * 1.3 + actions * self.bc["energy_per_action"]
        reach_charger = manhattan(self.cell, wh.charger) * e * 1.1
        if self.battery >= need or self.battery <= reach_charger:
            return False
        self._log("WARN", f"Battery {self.battery:.1f} cannot finish task (needs ~{need:.1f}) "
                          "- diverting to charger")
        self.mission, self.nav_state = "charge", RobotState.MOVING
        self.goals = {wh.charger}
        if self.cell == wh.charger:
            self._set_state(RobotState.CHARGING, "charging mid-task")
        else:
            self._begin_plan("initial")
        return True

    def _advance(self, dt: float) -> None:
        step = min(self.speed * dt, 1.0 - self.progress)
        self.progress += step
        self.ctx.metrics.distance_cells += step
        self._consume(self.bc["energy_per_cell"] * step)
        if self.progress >= 1.0 - 1e-9 and self.moving_to is not None:
            self.cell, self.moving_to, self.progress = self.moving_to, None, 0.0
            self.path_index += 1
            self._wait = 0.0            # real progress was made: restart the stall timer

    def _on_blocked(self, d: AvoidanceDecision) -> None:
        """Stopped before collision: record the encounter, remember it, replan."""
        key = d.obstacle_id or f"{d.kind}@{d.cell}"
        last = self._last_encounter.get(key)
        counted = last is None or self.now - last > self.rc["encounter_cooldown_s"]
        self._last_encounter[key] = self.now
        if counted:
            self.ctx.metrics.record_obstacle(d.movable)
            self._log("WARN", f"Obstacle ahead: {d.obstacle_id or d.kind} "
                              f"({'movable' if d.movable else 'static'} {d.kind}) at {d.cell}, "
                              f"{d.distance} cell(s) - stopped, replanning")
        self.ctx.memory.add(d.cell, self.now)
        self._task_replans += 1
        if self.task is not None and self._task_replans > self.rc["max_replans_per_task"]:
            self._navigation_failed(f"route blocked repeatedly ({self._task_replans - 1} replans)")
            return
        self._begin_plan("blocked")

    def _on_arrival(self) -> None:
        m = self.mission
        if m == "pickup":
            self._set_state(RobotState.PICKING, "scanning adjacent cells")
            self.sub, self.timer = "scan", self.rc["scan_time_s"]
            self._scan_neighbours()
        elif m == "delivery":
            self.sub, self.timer = "place", self.rc["place_time_s"]
            self.phase = "placing package"
            self._log("INFO", f"Arrived at delivery cell {self.cell}")
        elif m == "charge":
            self._set_state(RobotState.CHARGING, "charging before task")
        else:  # return
            self.mission = None
            self._clear_task()
            self._set_state(RobotState.IDLE, "idle")

    # ---------------------------------------------------------- picking
    def _scan_neighbours(self) -> None:
        ctx = self.ctx
        rec = ctx.get_recognizer()
        self.detections, self.target_detection = [], None
        for n in ctx.warehouse.neighbours4(self.cell):
            pid = ctx.warehouse.package_at.get(n)
            if pid:
                self.detections.append(rec.recognize(ctx.packages.get(pid), n, 1))
        self._consume(self.bc["energy_per_action"] * 0.5)

    def _update_picking(self, dt: float) -> None:
        ctx = self.ctx
        if self.sub == "scan":
            self.timer -= dt
            if self.timer > 0:
                return
            self._evaluate_scan()
        elif self.sub == "turn":
            tc = self._target_cell
            want = DIR_TO_ANGLE[(tc[0] - self.cell[0], tc[1] - self.cell[1])]
            if self._turn_to(want, dt):
                self.sub, self.timer = "grasp", self.rc["pick_time_s"]
                self.phase = "picking up package"
        elif self.sub == "grasp":
            self.timer -= dt
            if self.timer > 0:
                return
            ctx.packages.pickup(self.package.id)
            self.carrying = self.package.id
            self._consume(self.bc["energy_per_action"] * 0.5)
            if self.latched:
                return
            self._log("SUCCESS", f"Picked up {self.package.id}")
            self.mission, self.nav_state = "delivery", RobotState.DELIVERING
            self.goals = {ctx.warehouse.delivery_points[self.task.destination]}
            self.sub = None
            self._begin_plan("initial")

    def _evaluate_scan(self) -> None:
        pkg, mn = self.package, self.ctx.min_confidence
        match = next((d for d in self.detections if d.package_id == pkg.id), None)
        for d in self.detections:
            conf = "n/a" if d.confidence is None else f"{d.confidence:.3f}"
            self._log("INFO", f"Detected {d.package_id or '?'} ({d.category or '?'}) at {d.cell}, "
                              f"confidence {conf} [{d.method}]")
        if match is None:
            self._fail_task(f"{pkg.id} not identified at the pickup position")
        elif match.confidence is None or match.confidence < mn:
            self._fail_task(f"recognition confidence too low for {pkg.id}")
        elif match.category != pkg.category:
            self._fail_task(f"{pkg.id}: detected category '{match.category}' "
                            f"does not match record '{pkg.category}'")
        else:
            self.target_detection, self._target_cell = match, match.cell
            self._log("SUCCESS", f"Target {pkg.id} identified (confidence {match.confidence:.3f})")
            self.sub, self.phase = "turn", "facing package"

    # --------------------------------------------------------- placing
    def _finish_place(self) -> None:
        pkg = self.package
        self.ctx.packages.place(pkg.id, self.cell)
        self.carrying = None
        self._consume(self.bc["energy_per_action"] * 0.5)
        if not self.latched:
            self._complete_task()

    def _complete_task(self) -> None:
        task = self.task
        self.ctx.tasks.complete(task, self.now)
        self.ctx.metrics.record_task(True, task.duration)
        self._log("SUCCESS", f"Task {task.label()} completed in {task.duration:.1f} s")
        self.path, self.explored, self.sub = [], [], None
        self._set_state(RobotState.COMPLETED, "task completed")
        self.timer = self.rc["completed_display_s"]

    def _fail_task(self, reason: str, latch: bool = False) -> None:
        task, pkg = self.task, self.package
        if task is not None:
            self.ctx.tasks.fail(task, reason, self.now)
            self.ctx.metrics.record_task(False, 0.0)
            self._log("ERROR", f"Task {task.label()} FAILED: {reason}")
        if pkg is not None and pkg.status is PackageStatus.ASSIGNED:
            self.ctx.packages.release(pkg.id)
        elif pkg is not None and pkg.status is PackageStatus.CARRIED:
            latch = True
            reason += f" (still carrying {pkg.id})"
        self.path, self.explored, self.sub, self.mission = [], [], None, None
        self.error_message, self.latched = reason, latch
        self.timer = self.rc["error_display_s"]
        self._set_state(RobotState.ERROR, reason)
        if latch:
            self._log("ERROR", "Robot halted - press Reset to restore the simulation")

    # ------------------------------------------------ operator controls
    def emergency_stop(self) -> None:
        if self.estopped:
            return
        self.estopped, self._saved_state = True, self.state
        self._saved_phase = self.phase
        self._set_state(RobotState.ERROR, "EMERGENCY STOP")
        self._log("ERROR", "EMERGENCY STOP engaged - robot frozen")

    def release_estop(self) -> bool:
        if not self.estopped:
            return False
        self.estopped = False
        self._set_state(self._saved_state, getattr(self, "_saved_phase", "resumed"))
        self._log("INFO", "Emergency stop released - robot resuming")
        return True
