"""Grid-based A* path planning, implemented from scratch (no planning library).

* 4-directional movement (N, E, S, W), unit step cost.
* Manhattan-distance heuristic. With unit costs and 4-connected moves this
  heuristic is admissible *and* consistent, so the first time a goal is popped
  from the open list the path is optimal and a closed set is safe to use.
* Several goal cells may be supplied (e.g. every free cell next to a shelf).
  The heuristic is then the minimum Manhattan distance to any goal, which is
  still admissible and consistent.
* The planner reports the nodes it expanded (in order) so the UI can visualise
  the search.
"""
from __future__ import annotations

import heapq
import itertools
from dataclasses import dataclass, field
from typing import Callable, Collection, Iterable, Union

Cell = tuple[int, int]

# N, E, S, W  (screen coordinates: y grows downwards)
DIRECTIONS: tuple[Cell, ...] = ((0, -1), (1, 0), (0, 1), (-1, 0))


def manhattan(a: Cell, b: Cell) -> int:
    """Manhattan (L1) distance between two grid cells."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


@dataclass
class PathResult:
    """Outcome of one A* search."""

    found: bool
    path: list[Cell] = field(default_factory=list)      # start ... goal (inclusive)
    explored: list[Cell] = field(default_factory=list)  # expansion order
    cost: int = 0                                        # number of steps
    reason: str = ""

    @property
    def nodes_expanded(self) -> int:
        return len(self.explored)


class GridMap:
    """Minimal occupancy grid, handy for tests and stand-alone use."""

    def __init__(self, width: int, height: int, blocked: Iterable[Cell] = ()):
        self.width = width
        self.height = height
        self.blocked: set[Cell] = set(blocked)

    @classmethod
    def from_ascii(cls, rows: list[str], blocked_chars: str = "#S") -> "GridMap":
        blocked = {
            (x, y)
            for y, row in enumerate(rows)
            for x, ch in enumerate(row)
            if ch in blocked_chars
        }
        return cls(len(rows[0]), len(rows), blocked)

    def in_bounds(self, cell: Cell) -> bool:
        return 0 <= cell[0] < self.width and 0 <= cell[1] < self.height

    def passable(self, cell: Cell) -> bool:
        return self.in_bounds(cell) and cell not in self.blocked

    def find_path(self, start: Cell, goals: Union[Cell, Collection[Cell]],
                  extra_blocked: Collection[Cell] = ()) -> PathResult:
        extra = set(extra_blocked)
        return astar(self.width, self.height,
                     lambda c: self.passable(c) and c not in extra, start, goals)


def _normalise_goals(goals: Union[Cell, Collection[Cell]]) -> set[Cell]:
    if (isinstance(goals, tuple) and len(goals) == 2
            and all(isinstance(v, int) for v in goals)):
        return {goals}  # a single (x, y) cell
    return set(goals)


def astar(width: int, height: int, passable: Callable[[Cell], bool],
          start: Cell, goals: Union[Cell, Collection[Cell]]) -> PathResult:
    """Find a shortest 4-connected path from ``start`` to the nearest goal.

    ``passable(cell)`` decides whether a cell may be entered. The start cell is
    always allowed (the robot is already standing on it).
    """
    def in_bounds(c: Cell) -> bool:
        return 0 <= c[0] < width and 0 <= c[1] < height

    if not in_bounds(start):
        return PathResult(False, reason="start cell is outside the grid")

    goal_set = {g for g in _normalise_goals(goals)
                if in_bounds(g) and (g == start or passable(g))}
    if not goal_set:
        return PathResult(False, reason="no passable goal cell")

    def h(c: Cell) -> int:
        return min(manhattan(c, g) for g in goal_set)

    tie = itertools.count()  # FIFO tie-break keeps results deterministic
    h0 = h(start)
    open_heap: list[tuple[int, int, int, Cell]] = [(h0, h0, next(tie), start)]
    g_cost: dict[Cell, int] = {start: 0}
    parent: dict[Cell, Cell] = {}
    closed: set[Cell] = set()
    explored: list[Cell] = []

    while open_heap:
        _f, _h, _n, current = heapq.heappop(open_heap)
        if current in closed:
            continue  # stale heap entry
        closed.add(current)
        explored.append(current)

        if current in goal_set:
            path = [current]
            while path[-1] in parent:
                path.append(parent[path[-1]])
            path.reverse()
            return PathResult(True, path, explored, g_cost[current])

        for dx, dy in DIRECTIONS:
            nb = (current[0] + dx, current[1] + dy)
            if nb in closed or not in_bounds(nb) or not passable(nb):
                continue
            new_g = g_cost[current] + 1
            if new_g < g_cost.get(nb, 1 << 30):
                g_cost[nb] = new_g
                parent[nb] = current
                hn = h(nb)
                heapq.heappush(open_heap, (new_g + hn, hn, next(tie), nb))

    return PathResult(False, explored=explored, reason="no route to any goal")
