"""Simulation metrics and event log.

Every number is incremented by the code that performs the corresponding
action (a step moved, a plan computed, an obstacle sensed, ...). Nothing is
estimated or randomly generated.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field


@dataclass
class LogEntry:
    time: float
    level: str   # INFO | SUCCESS | WARN | ERROR
    text: str


class EventLog:
    def __init__(self, capacity: int = 300):
        self.entries: deque[LogEntry] = deque(maxlen=capacity)

    def add(self, level: str, time: float, text: str) -> None:
        self.entries.append(LogEntry(time, level, text))

    def last(self, n: int) -> list[LogEntry]:
        return list(self.entries)[-n:]


@dataclass
class Metrics:
    cell_size_m: float = 0.5
    distance_cells: float = 0.0
    obstacles_encountered: int = 0
    movable_encounters: int = 0
    static_encounters: int = 0
    replans: int = 0
    plans_computed: int = 0
    last_nodes_explored: int = 0
    last_plan_ms: float = 0.0
    tasks_completed: int = 0
    tasks_failed: int = 0
    energy_used: float = 0.0
    collisions: int = 0
    completion_times: list[float] = field(default_factory=list)

    @property
    def distance_m(self) -> float:
        return self.distance_cells * self.cell_size_m

    @property
    def last_completion_time(self):
        return self.completion_times[-1] if self.completion_times else None

    @property
    def average_completion_time(self):
        return (sum(self.completion_times) / len(self.completion_times)
                if self.completion_times else None)

    def record_plan(self, nodes: int, ms: float, replan: bool) -> None:
        self.plans_computed += 1
        self.last_nodes_explored = nodes
        self.last_plan_ms = ms
        if replan:
            self.replans += 1

    def record_obstacle(self, movable: bool) -> None:
        self.obstacles_encountered += 1
        if movable:
            self.movable_encounters += 1
        else:
            self.static_encounters += 1

    def record_task(self, success: bool, duration: float) -> None:
        if success:
            self.tasks_completed += 1
            self.completion_times.append(duration)
        else:
            self.tasks_failed += 1
