"""Loading and validation of the JSON warehouse / task configuration."""
from __future__ import annotations

import copy
import json
import re
from pathlib import Path
from typing import Any

LAYOUT_CHARS = set(".#SCPD")
WALKABLE_CHARS = set(".CPD")
MAX_NUMERIC_ID = (1 << 14) - 1  # package numbers are encoded in a 14-bit label

DEFAULTS: dict[str, Any] = {
    "name": "Warehouse",
    "cell_size_m": 0.5,
    "robot": {
        "start": None,                 # defaults to the charging station
        "speed_cells_per_s": 3.0,
        "turn_rate_deg_s": 540.0,
        "sensor_range_cells": 3,
        "scan_time_s": 1.0,
        "pick_time_s": 1.2,
        "place_time_s": 1.2,
        "plan_display_s": 0.6,
        "retry_plan_s": 0.25,
        "retry_interval_s": 1.0,
        "obstacle_memory_s": 6.0,
        "max_blocked_wait_s": 15.0,
        "max_replans_per_task": 40,
        "encounter_cooldown_s": 3.0,
        "completed_display_s": 1.0,
        "error_display_s": 2.0,
        "battery": {
            "capacity": 100.0,
            "energy_per_cell": 0.35,
            "energy_per_action": 0.8,
            "idle_drain_per_s": 0.01,
            "charge_rate_per_s": 8.0,
            "reserve": 10.0,
            "low_battery_pct": 20.0,
            "auto_return_to_charger": True,
        },
    },
    "recognition": {"mode": "sensor", "min_confidence": 0.6,
                    "noise_sigma": 4.0, "seed": 7},
    "movable_obstacles": [],
    "demo_tasks": [],
}


class ConfigError(ValueError):
    """Raised when the configuration file is missing or invalid."""


def _merge(defaults: dict, override: dict) -> dict:
    out = copy.deepcopy(defaults)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


def _cell(value: Any, what: str) -> tuple[int, int]:
    if (not isinstance(value, (list, tuple)) or len(value) != 2
            or not all(isinstance(v, int) and not isinstance(v, bool) for v in value)):
        raise ConfigError(f"{what}: expected [x, y] integers, got {value!r}")
    return (value[0], value[1])


def _number(section: dict, key: str, what: str, *, minimum: float = 0.0,
            allow_zero: bool = False) -> None:
    v = section.get(key)
    ok = isinstance(v, (int, float)) and not isinstance(v, bool)
    if not ok or v < minimum or (v == minimum and not allow_zero):
        raise ConfigError(f"{what}.{key} must be a number > {minimum}, got {v!r}")


def load_config(path: str | Path) -> dict:
    """Read, parse and validate a configuration file."""
    path = Path(path)
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise ConfigError(f"Configuration file not found: {path}") from None
    except OSError as exc:
        raise ConfigError(f"Cannot read configuration file {path}: {exc}") from None
    try:
        raw = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ConfigError(
            f"Invalid JSON in {path} (line {exc.lineno}, column {exc.colno}): {exc.msg}"
        ) from None
    return validate_config(raw)


def validate_config(raw: dict) -> dict:
    """Validate ``raw`` and return a normalised copy with defaults applied."""
    if not isinstance(raw, dict):
        raise ConfigError("Configuration root must be a JSON object")
    if raw.get("_validated"):           # already normalised - do not process twice
        return copy.deepcopy(raw)
    cfg = _merge(DEFAULTS, copy.deepcopy(raw))   # never mutate the caller's dict

    # ---- layout --------------------------------------------------------
    layout = cfg.get("layout")
    if (not isinstance(layout, list) or not layout
            or not all(isinstance(r, str) for r in layout)):
        raise ConfigError("'layout' must be a non-empty list of strings")
    width = len(layout[0])
    if width == 0 or any(len(r) != width for r in layout):
        raise ConfigError("all 'layout' rows must have the same, non-zero length")
    for y, row in enumerate(layout):
        for x, ch in enumerate(row):
            if ch not in LAYOUT_CHARS:
                raise ConfigError(
                    f"layout[{y}][{x}]: unknown character {ch!r} "
                    f"(allowed: {' '.join(sorted(LAYOUT_CHARS))})")
    height = len(layout)

    def ch_at(c):
        return layout[c[1]][c[0]] if 0 <= c[0] < width and 0 <= c[1] < height else None

    chargers = [(x, y) for y, r in enumerate(layout) for x, ch in enumerate(r) if ch == "C"]
    if not chargers:
        raise ConfigError("layout needs at least one charging station 'C'")

    # ---- numbers -------------------------------------------------------
    _number(cfg, "cell_size_m", "config")
    robot = cfg["robot"]
    for key in ("speed_cells_per_s", "turn_rate_deg_s", "sensor_range_cells",
                "scan_time_s", "pick_time_s", "place_time_s", "plan_display_s",
                "retry_plan_s", "retry_interval_s", "obstacle_memory_s",
                "max_blocked_wait_s", "max_replans_per_task", "encounter_cooldown_s",
                "completed_display_s", "error_display_s"):
        _number(robot, key, "robot")
    battery = robot["battery"]
    for key in ("capacity", "energy_per_cell", "charge_rate_per_s"):
        _number(battery, key, "robot.battery")
    for key in ("energy_per_action", "idle_drain_per_s", "reserve", "low_battery_pct"):
        _number(battery, key, "robot.battery", minimum=0.0, allow_zero=True)
    robot["sensor_range_cells"] = int(robot["sensor_range_cells"])

    # ---- robot start ---------------------------------------------------
    start = chargers[0] if robot["start"] is None else _cell(robot["start"], "robot.start")
    if ch_at(start) not in WALKABLE_CHARS:
        raise ConfigError(f"robot.start {start} is not on a walkable cell")
    robot["start"] = start

    # ---- categories ----------------------------------------------------
    cats = cfg.get("categories")
    if not isinstance(cats, dict) or not cats:
        raise ConfigError("'categories' must be a non-empty object")
    for name, spec in cats.items():
        col = spec.get("color") if isinstance(spec, dict) else None
        if (not isinstance(col, list) or len(col) != 3
                or not all(isinstance(v, int) and 0 <= v <= 255 for v in col)):
            raise ConfigError(f"categories.{name}.color must be [r, g, b] with 0-255 ints")
        spec["color"] = tuple(col)

    # ---- packages ------------------------------------------------------
    packages = cfg.get("packages")
    if not isinstance(packages, list):
        raise ConfigError("'packages' must be a list")
    ids, numbers, cells = set(), set(), set()
    for i, p in enumerate(packages):
        if not isinstance(p, dict) or "id" not in p:
            raise ConfigError(f"packages[{i}] needs an 'id'")
        pid = str(p["id"]).strip().upper()
        p["id"] = pid
        if pid in ids:
            raise ConfigError(f"duplicate package id {pid}")
        ids.add(pid)
        m = re.search(r"(\d+)$", pid)
        if not m or not (1 <= int(m.group(1)) <= MAX_NUMERIC_ID):
            raise ConfigError(f"package id {pid} must end in a number 1-{MAX_NUMERIC_ID}")
        if int(m.group(1)) in numbers:
            raise ConfigError(f"package id {pid} reuses another package's number")
        numbers.add(int(m.group(1)))
        if p.get("category") not in cats:
            raise ConfigError(f"package {pid}: unknown category {p.get('category')!r}")
        cell = _cell(p.get("cell"), f"package {pid}.cell")
        if ch_at(cell) not in ("S", "P"):
            raise ConfigError(f"package {pid} at {cell} must be on a shelf 'S' or pickup 'P' cell")
        if cell in cells:
            raise ConfigError(f"package {pid}: cell {cell} already holds another package")
        cells.add(cell)
        p["cell"] = cell
    for p in packages:  # every package needs at least one free neighbour to be picked from
        x, y = p["cell"]
        nbs = [(x + dx, y + dy) for dx, dy in ((0, -1), (1, 0), (0, 1), (-1, 0))]
        if not any(ch_at(n) in WALKABLE_CHARS and n not in cells for n in nbs):
            raise ConfigError(f"package {p['id']} at {p['cell']} has no accessible neighbour cell")

    # ---- delivery points ----------------------------------------------
    dps = cfg.get("delivery_points")
    if not isinstance(dps, dict) or not dps:
        raise ConfigError("'delivery_points' must be a non-empty object")
    norm = {}
    for name, c in dps.items():
        cell = _cell(c, f"delivery_points.{name}")
        if ch_at(cell) != "D":
            raise ConfigError(f"delivery point {name} at {cell} must be on a 'D' cell")
        norm[str(name).strip().upper()] = cell
    cfg["delivery_points"] = norm

    # ---- movable obstacles --------------------------------------------
    seen = set()
    for i, o in enumerate(cfg["movable_obstacles"]):
        oid = str(o.get("id", f"OBS-{i}"))
        if oid in seen:
            raise ConfigError(f"duplicate obstacle id {oid}")
        seen.add(oid)
        o["id"] = oid
        kind = o.get("kind")
        if kind not in ("cart", "crate"):
            raise ConfigError(f"obstacle {oid}: kind must be 'cart' or 'crate'")
        if kind == "crate":
            cell = _cell(o.get("cell"), f"obstacle {oid}.cell")
            if ch_at(cell) not in (".", "P", "D") or cell in cells:
                raise ConfigError(f"crate {oid} at {cell} must sit on a free floor cell")
            o["cell"] = cell
        else:
            pts = o.get("patrol")
            if not isinstance(pts, list) or len(pts) != 2:
                raise ConfigError(f"cart {oid}: 'patrol' needs two end points [[x,y],[x,y]]")
            a, b = _cell(pts[0], f"cart {oid}.patrol[0]"), _cell(pts[1], f"cart {oid}.patrol[1]")
            if a[0] != b[0] and a[1] != b[1]:
                raise ConfigError(f"cart {oid}: patrol end points must share a row or column")
            line = _line(a, b)
            for c in line:
                if ch_at(c) not in WALKABLE_CHARS or c in cells:
                    raise ConfigError(f"cart {oid}: patrol cell {c} is not free floor")
            o["patrol"] = line
            o["speed_cells_per_s"] = float(o.get("speed_cells_per_s", 1.0))
            if o["speed_cells_per_s"] <= 0:
                raise ConfigError(f"cart {oid}: speed_cells_per_s must be > 0")

    # ---- recognition / demo tasks -------------------------------------
    rec = cfg["recognition"]
    if rec["mode"] not in ("sensor", "opencv"):
        raise ConfigError("recognition.mode must be 'sensor' or 'opencv'")
    if not (0.0 <= rec["min_confidence"] <= 1.0):
        raise ConfigError("recognition.min_confidence must be within 0..1")
    for i, t in enumerate(cfg["demo_tasks"]):
        t["package"] = str(t.get("package", "")).strip().upper()
        t["destination"] = str(t.get("destination", "")).strip().upper()
        if t["package"] not in ids or t["destination"] not in norm:
            raise ConfigError(f"demo_tasks[{i}] references an unknown package or destination")
    cfg["_validated"] = True
    return cfg


def _line(a: tuple[int, int], b: tuple[int, int]) -> list[tuple[int, int]]:
    """All cells on the straight horizontal/vertical segment a..b inclusive."""
    if a[0] == b[0]:
        step = 1 if b[1] >= a[1] else -1
        return [(a[0], y) for y in range(a[1], b[1] + step, step)]
    step = 1 if b[0] >= a[0] else -1
    return [(x, a[1]) for x in range(a[0], b[0] + step, step)]
