"""Delivery task queue with input validation."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from .package_manager import PackageManager, PackageStatus
from .path_planning import astar
from .warehouse import Warehouse

Cell = tuple[int, int]


class TaskStatus(Enum):
    QUEUED = "QUEUED"
    ACTIVE = "ACTIVE"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


@dataclass
class Task:
    id: int
    package_id: str
    destination: str
    created_at: float
    status: TaskStatus = TaskStatus.QUEUED
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    failure_reason: str = ""

    @property
    def duration(self) -> Optional[float]:
        if self.started_at is None or self.finished_at is None:
            return None
        return self.finished_at - self.started_at

    def label(self) -> str:
        return f"#{self.id} {self.package_id} -> {self.destination}"


@dataclass
class SubmitResult:
    ok: bool
    message: str
    task: Optional[Task] = None


class TaskManager:
    def __init__(self, warehouse: Warehouse, packages: PackageManager):
        self.warehouse = warehouse
        self.packages = packages
        self.queue: deque[Task] = deque()
        self.history: list[Task] = []     # every task ever created, in order
        self._next_id = 1

    # ----------------------------------------------------------- validation
    def _reachable(self, origin: Cell, goals) -> bool:
        wh = self.warehouse
        return astar(wh.width, wh.height, lambda c: not wh.is_map_blocked(c),
                     origin, goals).found

    def submit(self, package_id: str, destination: str, origin: Cell,
               now: float = 0.0) -> SubmitResult:
        pid = str(package_id).strip().upper()
        dest = str(destination).strip().upper()
        if not pid:
            return SubmitResult(False, "Enter a package ID (e.g. PKG-001)")
        pkg = self.packages.get(pid)
        if pkg is None:
            return SubmitResult(False, f"Invalid package ID '{pid}'")
        if not dest:
            return SubmitResult(False, "Enter a delivery destination (e.g. D1)")
        if dest not in self.warehouse.delivery_points:
            known = ", ".join(sorted(self.warehouse.delivery_points))
            return SubmitResult(False, f"Unknown destination '{dest}' (valid: {known})")
        if pkg.status is PackageStatus.DELIVERED:
            return SubmitResult(False, f"{pid} was already delivered")
        if pkg.status is PackageStatus.CARRIED:
            return SubmitResult(False, f"{pid} is currently being carried")
        if pkg.status is PackageStatus.ASSIGNED:
            return SubmitResult(False, f"{pid} is already assigned to task #{pkg.task_id}")
        if not self._reachable(origin, self.packages.access_cells(pid)):
            return SubmitResult(False, f"{pid} is unreachable: no free route to its shelf")
        if not self._reachable(origin, {self.warehouse.delivery_points[dest]}):
            return SubmitResult(False, f"Destination {dest} is unreachable")
        task = Task(self._next_id, pid, dest, now)
        self._next_id += 1
        self.packages.assign(pid, task.id)
        self.queue.append(task)
        self.history.append(task)
        return SubmitResult(True, f"Task {task.label()} queued", task)

    # -------------------------------------------------------------- queue
    def has_queued(self) -> bool:
        return bool(self.queue)

    def start_next(self, now: float) -> Task:
        task = self.queue.popleft()
        task.status, task.started_at = TaskStatus.ACTIVE, now
        return task

    def complete(self, task: Task, now: float) -> None:
        task.status, task.finished_at = TaskStatus.COMPLETED, now

    def fail(self, task: Task, reason: str, now: float) -> None:
        task.status, task.finished_at, task.failure_reason = TaskStatus.FAILED, now, reason

    def recent(self, n: int) -> list[Task]:
        return self.history[-n:]
