"""Warehouse grid world: static map, packages' occupancy, movable obstacles.

Obstacle taxonomy
-----------------
* STATIC   - walls and shelves. Part of the robot's known map; never move.
* PACKAGE  - a package waiting in its slot blocks that cell until picked.
* MOVABLE  - carts (patrol a corridor) and crates (stay put until removed).
             They are NOT in the robot's map: it can only discover them with
             its (simulated) proximity sensors.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Optional

Cell = tuple[int, int]
NEIGHBOURS: tuple[Cell, ...] = ((0, -1), (1, 0), (0, 1), (-1, 0))


class CellType(Enum):
    FREE = "."
    WALL = "#"
    SHELF = "S"
    CHARGER = "C"
    PICKUP = "P"
    DELIVERY = "D"


STATIC_BLOCKING = (CellType.WALL, CellType.SHELF)


@dataclass(frozen=True)
class Occupant:
    """What a sensor ray hits in a cell."""
    kind: str            # wall | shelf | package | cart | crate | boundary
    id: Optional[str]
    movable: bool


class MovableObstacle:
    """A cart (patrols between two points) or a crate (stationary)."""

    REVERSE_AFTER_S = 1.5  # a cart blocked this long turns around

    def __init__(self, oid: str, kind: str, cell: Cell,
                 patrol: Optional[list[Cell]] = None, speed: float = 1.0,
                 user_placed: bool = False):
        self.id = oid
        self.kind = kind
        self.cell = cell
        self.target: Optional[Cell] = None
        self.progress = 0.0
        self.patrol = patrol or []
        self.speed = speed
        self.user_placed = user_placed
        self._idx = 0
        self._target_idx = 0
        self._dir = 1
        self._blocked_for = 0.0

    @property
    def pos(self) -> tuple[float, float]:
        """Interpolated position for drawing."""
        if self.target is None:
            return (float(self.cell[0]), float(self.cell[1]))
        return (self.cell[0] + (self.target[0] - self.cell[0]) * self.progress,
                self.cell[1] + (self.target[1] - self.cell[1]) * self.progress)

    def occupied_cells(self) -> set[Cell]:
        cells = {self.cell}
        if self.target is not None:
            cells.add(self.target)
        return cells

    def update(self, dt: float, world: "Warehouse", robot_cells: set[Cell]) -> None:
        if self.kind != "cart" or len(self.patrol) < 2:
            return
        if self.target is None:
            nxt = self._idx + self._dir
            if nxt < 0 or nxt >= len(self.patrol):
                self._dir = -self._dir
                nxt = self._idx + self._dir
            cand = self.patrol[nxt]
            if world.can_obstacle_enter(cand, self, robot_cells):
                self.target, self._target_idx, self.progress = cand, nxt, 0.0
                self._blocked_for = 0.0
            else:
                self._blocked_for += dt
                if self._blocked_for >= self.REVERSE_AFTER_S:
                    self._dir = -self._dir
                    self._blocked_for = 0.0
        else:
            self.progress += self.speed * dt
            if self.progress >= 1.0:
                self.cell, self._idx = self.target, self._target_idx
                self.target, self.progress = None, 0.0


class Warehouse:
    """Grid map plus dynamic occupancy."""

    def __init__(self, cfg: dict):
        rows: list[str] = cfg["layout"]
        self.name: str = cfg["name"]
        self.cell_size_m: float = cfg["cell_size_m"]
        self.height = len(rows)
        self.width = len(rows[0])
        self.grid = [[CellType(ch) for ch in row] for row in rows]
        self.charger: Cell = next((x, y) for y, r in enumerate(self.grid)
                                  for x, t in enumerate(r) if t is CellType.CHARGER)
        self.start: Cell = tuple(cfg["robot"]["start"])  # type: ignore[assignment]
        self.delivery_points: dict[str, Cell] = dict(cfg["delivery_points"])
        self.package_at: dict[Cell, str] = {}  # maintained by PackageManager
        self.obstacles: list[MovableObstacle] = []
        self._user_crates = 0
        for o in cfg["movable_obstacles"]:
            if o["kind"] == "cart":
                self.obstacles.append(MovableObstacle(
                    o["id"], "cart", o["patrol"][0], o["patrol"], o["speed_cells_per_s"]))
            else:
                self.obstacles.append(MovableObstacle(o["id"], "crate", tuple(o["cell"])))

    # ------------------------------------------------------------ queries
    def in_bounds(self, c: Cell) -> bool:
        return 0 <= c[0] < self.width and 0 <= c[1] < self.height

    def cell_type(self, c: Cell) -> CellType:
        return self.grid[c[1]][c[0]]

    def neighbours4(self, c: Cell) -> list[Cell]:
        return [(c[0] + dx, c[1] + dy) for dx, dy in NEIGHBOURS
                if self.in_bounds((c[0] + dx, c[1] + dy))]

    def is_static_blocked(self, c: Cell) -> bool:
        return not self.in_bounds(c) or self.cell_type(c) in STATIC_BLOCKING

    def is_map_blocked(self, c: Cell) -> bool:
        """What the robot *knows* is blocked: static map + stored packages."""
        return self.is_static_blocked(c) or c in self.package_at

    def obstacle_at(self, c: Cell) -> Optional[MovableObstacle]:
        for o in self.obstacles:
            if c in o.occupied_cells():
                return o
        return None

    def is_physically_blocked(self, c: Cell) -> bool:
        """Ground truth, including movable obstacles."""
        return self.is_map_blocked(c) or self.obstacle_at(c) is not None

    def occupant(self, c: Cell) -> Optional[Occupant]:
        """Ground-truth description of whatever blocks ``c`` (None if free)."""
        if not self.in_bounds(c):
            return Occupant("boundary", None, False)
        if c in self.package_at:
            return Occupant("package", self.package_at[c], False)
        t = self.cell_type(c)
        if t is CellType.WALL:
            return Occupant("wall", None, False)
        if t is CellType.SHELF:
            return Occupant("shelf", None, False)
        o = self.obstacle_at(c)
        if o is not None:
            return Occupant(o.kind, o.id, True)
        return None

    def cell_label(self, c: Cell) -> str:
        if not self.in_bounds(c):
            return "outside"
        occ = self.occupant(c)
        base = self.cell_type(c).name
        return f"{base} ({occ.kind}{' ' + occ.id if occ and occ.id else ''})" if occ else base

    # ------------------------------------------------------ dynamic world
    def can_obstacle_enter(self, c: Cell, who: MovableObstacle, robot_cells: set[Cell]) -> bool:
        if not self.in_bounds(c) or self.is_map_blocked(c) or c in robot_cells:
            return False
        return all(o is who or c not in o.occupied_cells() for o in self.obstacles)

    def update_obstacles(self, dt: float, robot_cells: set[Cell]) -> None:
        for o in self.obstacles:
            o.update(dt, self, robot_cells)

    def add_crate(self, c: Cell, robot_cells: Iterable[Cell]) -> tuple[bool, str]:
        if not self.in_bounds(c):
            return False, "Cell is outside the warehouse"
        if self.cell_type(c) not in (CellType.FREE, CellType.PICKUP, CellType.DELIVERY):
            return False, f"Cannot place a crate on {self.cell_type(c).name}"
        if c in self.package_at:
            return False, "A package occupies that cell"
        if c in set(robot_cells):
            return False, "The robot occupies that cell"
        if self.obstacle_at(c) is not None:
            return False, "Another obstacle occupies that cell"
        self._user_crates += 1
        self.obstacles.append(MovableObstacle(f"CRATE-U{self._user_crates}", "crate", c,
                                              user_placed=True))
        return True, f"Crate placed at {c}"

    def remove_crate(self, c: Cell) -> tuple[bool, str]:
        for o in self.obstacles:
            if o.kind == "crate" and o.cell == c:
                self.obstacles.remove(o)
                return True, f"Crate {o.id} removed from {c}"
        return False, "No crate at that cell"

    def toggle_crate(self, c: Cell, robot_cells: Iterable[Cell]) -> tuple[bool, str]:
        if any(o.kind == "crate" and o.cell == c for o in self.obstacles):
            return self.remove_crate(c)
        return self.add_crate(c, robot_cells)
