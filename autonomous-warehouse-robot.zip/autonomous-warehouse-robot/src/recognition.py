"""Package recognition.

Two interchangeable recognizers, both operating on SIMULATED input:

``SimulatedSensorRecognizer`` ("sensor")
    A simulated colour sensor reads the package's RGB (attenuated by viewing
    distance, plus seeded Gaussian sensor noise) and a simulated RFID tag
    reader returns the package ID. The *category* is classified by comparing
    the reading's chromaticity with the known category colours; the
    confidence is the margin ``1 - d_best / d_second`` computed from those
    distances. The tag read itself carries no confidence.

``OpenCVRecognizer`` ("opencv")
    Renders a synthetic camera frame of the package (coloured box with a 4x4
    black/white ID label, illumination and noise) and then processes it with
    OpenCV: HSV segmentation -> contour -> bounding box -> colour
    classification and label decoding by thresholding the cell means.
    Confidence = min(colour margin, label contrast/margin score).

Neither uses a learned model, and neither confidence is random: the noise is
injected into the *sensor input* (seeded, so runs are reproducible) and the
score is calculated from what the algorithm then measures. When nothing is
measured (empty cell, failed decode) the confidence is ``None``.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Any, Optional

from .package_manager import Package

Cell = tuple[int, int]

try:  # OpenCV / NumPy are optional
    import cv2
    import numpy as np
    OPENCV_AVAILABLE = True
except Exception:  # pragma: no cover - depends on the environment
    cv2 = None  # type: ignore[assignment]
    np = None  # type: ignore[assignment]
    OPENCV_AVAILABLE = False

FRAME = 96            # synthetic camera frame size in pixels
LABEL_GRID = 4        # label is LABEL_GRID x LABEL_GRID cells
DATA_CELLS = LABEL_GRID * LABEL_GRID - 2   # first cell is white, last is black (anchors)


@dataclass
class Detection:
    cell: Cell
    package_id: Optional[str]
    category: Optional[str]
    confidence: Optional[float]        # None unless actually calculated
    method: str
    note: str = ""
    colour_confidence: Optional[float] = None
    label_confidence: Optional[float] = None
    frame: Any = None                  # BGR ndarray for the UI (opencv mode only)


# --------------------------------------------------------------- shared maths
def _chroma(rgb) -> tuple[float, float]:
    s = float(sum(rgb)) or 1.0
    return rgb[0] / s, rgb[1] / s


def classify_colour(rgb, categories: dict[str, tuple]) -> tuple[Optional[str], float]:
    """Nearest category by chromaticity (illumination-invariant) + margin score."""
    ch = _chroma(rgb)
    ranked = sorted((math.dist(ch, _chroma(col)), name) for name, col in categories.items())
    d1, best = ranked[0]
    if len(ranked) == 1:
        return best, max(0.0, 1.0 - d1 / 0.15)
    d2 = ranked[1][0]
    return best, (max(0.0, 1.0 - d1 / d2) if d2 > 0 else 0.0)


def _illumination(distance_cells: int) -> float:
    """Simple deterministic fall-off with viewing distance (1 cell -> 0.95)."""
    return 1.0 / (1.0 + 0.05 * max(distance_cells, 1))


# ---------------------------------------------------------------- recognizers
class SimulatedSensorRecognizer:
    name = "sensor"
    label = "simulated colour sensor + RFID tag"

    def __init__(self, categories: dict[str, tuple], noise_sigma: float = 4.0, seed: int = 7):
        self.categories = categories
        self.noise_sigma = noise_sigma
        self.seed = seed

    def recognize(self, package: Optional[Package], cell: Cell, distance: int = 1) -> Detection:
        if package is None:
            return Detection(cell, None, None, None, self.name, "nothing detected in cell")
        rng = random.Random(f"{self.seed}:{package.id}:{distance}")
        illum = _illumination(distance)
        rgb = [min(255.0, max(0.0, c * illum + rng.gauss(0.0, self.noise_sigma)))
               for c in package.color]
        category, conf = classify_colour(rgb, self.categories)
        return Detection(cell, package.id, category, conf, self.name,
                         "colour sensor + tag read", colour_confidence=conf)


class OpenCVRecognizer:
    name = "opencv"
    label = "OpenCV on a synthetic camera frame"

    def __init__(self, categories: dict[str, tuple], id_catalog: dict[int, str],
                 noise_sigma: float = 4.0, seed: int = 7):
        if not OPENCV_AVAILABLE:
            raise ImportError("opencv-python / numpy are not installed")
        self.categories = categories
        self.id_catalog = id_catalog
        self.noise_sigma = noise_sigma
        self.seed = seed

    # ---- synthetic camera --------------------------------------------
    def render_frame(self, package: Package, distance: int = 1):
        illum = _illumination(distance)
        img = np.full((FRAME, FRAME, 3), (95, 92, 88), np.uint8)          # grey floor/shelf
        m = FRAME // 8
        r, g, b = package.color
        cv2.rectangle(img, (m, m), (FRAME - m - 1, FRAME - m - 1),
                      (b * illum, g * illum, r * illum), -1)               # package body
        side = (FRAME - 2 * m) * 2 // 3                                     # label square
        x0 = y0 = (FRAME - side) // 2
        cell_px = side // LABEL_GRID
        bits = [package.number >> i & 1 for i in range(DATA_CELLS)]
        values = [0] + bits + [1]                                           # anchors: white..black
        for i, bit in enumerate(values):
            cx, cy = x0 + (i % LABEL_GRID) * cell_px, y0 + (i // LABEL_GRID) * cell_px
            shade = 20 * illum if bit else 245 * illum
            cv2.rectangle(img, (cx, cy), (cx + cell_px - 1, cy + cell_px - 1),
                          (shade, shade, shade), -1)
        rng = np.random.default_rng([self.seed, package.number, distance])
        noisy = img.astype(np.float32) + rng.normal(0.0, self.noise_sigma, img.shape)
        return np.clip(noisy, 0, 255).astype(np.uint8)

    # ---- image processing -----------------------------------------------
    def recognize(self, package: Optional[Package], cell: Cell, distance: int = 1) -> Detection:
        if package is None:
            return Detection(cell, None, None, None, self.name, "nothing detected in cell")
        frame = self.render_frame(package, distance)
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (0, 70, 40), (180, 255, 255))               # saturated pixels
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return Detection(cell, None, None, None, self.name, "no package found in frame", frame=frame)
        x, y, w, h = cv2.boundingRect(max(contours, key=cv2.contourArea))
        if w < FRAME // 4 or h < FRAME // 4:
            return Detection(cell, None, None, None, self.name, "segmented region too small", frame=frame)

        lx0, lx1 = x + w // 6, x + 5 * w // 6                               # central label region
        ly0, ly1 = y + h // 6, y + 5 * h // 6
        body = mask.copy()
        body[ly0:ly1, lx0:lx1] = 0
        if cv2.countNonZero(body) == 0:
            return Detection(cell, None, None, None, self.name, "no body pixels", frame=frame)
        b, g, r = cv2.mean(frame, mask=body)[:3]
        category, colour_conf = classify_colour((r, g, b), self.categories)

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)[ly0:ly1, lx0:lx1]
        means = cv2.resize(gray, (LABEL_GRID, LABEL_GRID), interpolation=cv2.INTER_AREA)
        vals = means.astype(np.float64).ravel()
        lo, hi = float(vals.min()), float(vals.max())
        contrast = hi - lo
        if contrast < 40.0:
            return Detection(cell, None, category, None, self.name, "label contrast too low",
                             colour_confidence=colour_conf, frame=frame)
        thr = (lo + hi) / 2.0
        dark = vals < thr
        number = sum(int(dark[1 + i]) << i for i in range(DATA_CELLS))
        label_conf = float(np.clip(np.mean(np.abs(vals - thr) / (contrast / 2.0)), 0, 1)
                           * min(1.0, contrast / 150.0))
        pid = self.id_catalog.get(number)
        if pid is None:
            return Detection(cell, None, category, None, self.name,
                             f"label decodes to unknown number {number}",
                             colour_confidence=colour_conf, label_confidence=label_conf, frame=frame)
        return Detection(cell, pid, category, min(colour_conf, label_conf), self.name,
                         "segmentation + label decode", colour_conf, label_conf, frame)


def make_recognizers(categories: dict[str, tuple], id_catalog: dict[int, str],
                     noise_sigma: float, seed: int) -> dict[str, Any]:
    """Build every recognizer that can run in this environment."""
    out: dict[str, Any] = {"sensor": SimulatedSensorRecognizer(categories, noise_sigma, seed)}
    if OPENCV_AVAILABLE:
        out["opencv"] = OpenCVRecognizer(categories, id_catalog, noise_sigma, seed)
    return out
