"""Obstacle detection and avoidance.

IMPORTANT: everything here is SIMULATED. The "proximity sensors" are grid
ray-casts against the simulator's ground-truth world model. They are neither
LiDAR nor camera implementations and carry no sensor noise or physics model.
On a real robot this module's interface (``scan`` -> readings) is where a
LiDAR/ultrasonic driver would plug in.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Protocol, Sequence

from .warehouse import Occupant

Cell = tuple[int, int]


class WorldView(Protocol):
    def occupant(self, c: Cell) -> Optional[Occupant]: ...


@dataclass
class SensorReading:
    name: str                         # front | left | right
    direction: Cell
    max_range: int
    distance: Optional[int] = None    # cells to first obstacle, None = clear
    obstacle_cell: Optional[Cell] = None
    obstacle: Optional[Occupant] = None
    free_cells: list[Cell] = field(default_factory=list)

    @property
    def hit(self) -> bool:
        return self.distance is not None


class ProximitySensorArray:
    """Three simulated ray-cast range sensors (front, left, right)."""

    def __init__(self, world: WorldView, max_range: int):
        self.world = world
        self.max_range = max_range

    def scan(self, cell: Cell, heading: Cell) -> dict[str, SensorReading]:
        dirs = {
            "front": heading,
            "left": (heading[1], -heading[0]),
            "right": (-heading[1], heading[0]),
        }
        out: dict[str, SensorReading] = {}
        for name, d in dirs.items():
            reading = SensorReading(name, d, self.max_range)
            for step in range(1, self.max_range + 1):
                c = (cell[0] + d[0] * step, cell[1] + d[1] * step)
                occ = self.world.occupant(c)
                if occ is not None:
                    reading.distance, reading.obstacle_cell, reading.obstacle = step, c, occ
                    break
                reading.free_cells.append(c)
            out[name] = reading
        return out


class ObstacleMemory:
    """Cells the robot recently saw blocked by a movable obstacle.

    Entries expire after ``ttl`` seconds (movable obstacles move away) or as
    soon as a sensor ray sees the cell free again.
    """

    def __init__(self, ttl: float):
        self.ttl = ttl
        self._until: dict[Cell, float] = {}

    def add(self, cell: Cell, now: float) -> None:
        self._until[cell] = now + self.ttl

    def forget(self, cell: Cell) -> None:
        self._until.pop(cell, None)

    def active(self, now: float) -> set[Cell]:
        self._until = {c: t for c, t in self._until.items() if t > now}
        return set(self._until)

    def clear(self) -> None:
        self._until.clear()


@dataclass
class AvoidanceDecision:
    blocked: bool
    cell: Optional[Cell] = None
    kind: str = ""
    obstacle_id: Optional[str] = None
    distance: int = 0
    movable: bool = False


class CollisionAvoidance:
    """Decides whether the planned route is blocked by something sensed."""

    def __init__(self, memory: ObstacleMemory):
        self.memory = memory

    def assess(self, readings: dict[str, SensorReading],
               remaining_path: Sequence[Cell]) -> AvoidanceDecision:
        # Anything a ray crossed without hitting is evidently free now.
        for r in readings.values():
            for c in r.free_cells:
                self.memory.forget(c)
        front = readings["front"]
        if not front.hit or front.obstacle_cell not in set(remaining_path):
            return AvoidanceDecision(False)
        occ = front.obstacle
        assert occ is not None and front.distance is not None
        return AvoidanceDecision(True, front.obstacle_cell, occ.kind, occ.id,
                                 front.distance, occ.movable)
