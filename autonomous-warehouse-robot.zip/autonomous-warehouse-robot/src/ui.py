"""Pygame front-end: warehouse canvas, controls, task panel, status, metrics, log."""
from __future__ import annotations

import math
from typing import Callable, Optional

import pygame

from .package_manager import PackageStatus
from .robot import RobotState
from .simulation import Simulation
from .task_manager import TaskStatus
from .warehouse import CellType

W, H = 1280, 720

C = {
    "bg": (18, 20, 26), "panel": (27, 30, 39), "panel_edge": (52, 58, 74),
    "text": (222, 226, 236), "dim": (130, 138, 156), "title": (120, 190, 255),
    "free": (36, 40, 50), "grid": (48, 53, 65), "wall": (78, 82, 94), "wall_in": (58, 62, 72),
    "shelf": (122, 88, 54), "shelf_in": (94, 66, 40), "charger": (28, 72, 84),
    "pickup": (74, 66, 28), "delivery": (30, 76, 48),
    "path": (255, 214, 70), "explored": (90, 150, 255, 64), "ok": (96, 214, 130),
    "warn": (255, 190, 80), "err": (255, 96, 96), "info": (170, 184, 210),
}
STATE_COLOR = {
    RobotState.IDLE: (120, 140, 170), RobotState.PLANNING: (240, 210, 70),
    RobotState.MOVING: (90, 210, 120), RobotState.PICKING: (250, 150, 60),
    RobotState.DELIVERING: (70, 200, 220), RobotState.COMPLETED: (130, 255, 160),
    RobotState.ERROR: (255, 80, 80), RobotState.CHARGING: (180, 120, 255),
}
LEVEL_COLOR = {"INFO": C["info"], "SUCCESS": C["ok"], "WARN": C["warn"], "ERROR": C["err"]}
HEADINGS = ["E", "SE", "S", "SW", "W", "NW", "N", "NE"]


class Button:
    def __init__(self, rect, label, on_click: Callable[[], None], color=(52, 62, 86),
                 active: Callable[[], bool] = lambda: False,
                 label_fn: Optional[Callable[[], str]] = None):
        self.rect = pygame.Rect(rect)
        self.label, self.on_click, self.color = label, on_click, color
        self.active, self.label_fn = active, label_fn

    def draw(self, surf, font, mouse):
        hover = self.rect.collidepoint(mouse)
        base = self.color
        col = tuple(min(255, c + (28 if hover else 0) + (40 if self.active() else 0)) for c in base)
        pygame.draw.rect(surf, col, self.rect, border_radius=5)
        pygame.draw.rect(surf, C["panel_edge"], self.rect, 1, border_radius=5)
        text = self.label_fn() if self.label_fn else self.label
        img = font.render(text, True, C["text"])
        surf.blit(img, img.get_rect(center=self.rect.center))

    def handle(self, event) -> bool:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 \
                and self.rect.collidepoint(event.pos):
            self.on_click()
            return True
        return False


class TextInput:
    def __init__(self, rect, text="", max_len=12):
        self.rect, self.text, self.max_len, self.focused = pygame.Rect(rect), text, max_len, False

    def draw(self, surf, font):
        pygame.draw.rect(surf, (14, 16, 22), self.rect, border_radius=4)
        pygame.draw.rect(surf, C["title"] if self.focused else C["panel_edge"], self.rect, 1,
                         border_radius=4)
        shown = self.text + ("|" if self.focused and pygame.time.get_ticks() // 500 % 2 == 0 else "")
        surf.blit(font.render(shown, True, C["text"]), (self.rect.x + 6, self.rect.y + 4))

    def handle(self, event) -> Optional[str]:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.focused = self.rect.collidepoint(event.pos)
        elif event.type == pygame.KEYDOWN and self.focused:
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                return "submit"
            if event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            elif event.key == pygame.K_ESCAPE:
                self.focused = False
            elif event.unicode and event.unicode.isprintable() and len(self.text) < self.max_len:
                self.text += event.unicode.upper()
        return None


def _font(size: int, bold: bool = False) -> pygame.font.Font:
    try:
        f = pygame.font.SysFont("dejavusansmono,consolas,menlo,couriernew,monospace", size, bold=bold)
        if f is not None:
            return f
    except Exception:
        pass
    return pygame.font.Font(None, size + 4)   # built-in fallback: never crash on missing fonts


class App:
    SPEEDS = (1, 2, 4, 8)

    def __init__(self, sim: Simulation, size=(W, H)):
        pygame.display.init()      # the simulator needs no audio, so skip pygame.mixer
        pygame.font.init()
        try:
            self.screen = pygame.display.set_mode(size, pygame.RESIZABLE | pygame.SCALED)
        except pygame.error:
            self.screen = pygame.display.set_mode(size)
        pygame.display.set_caption("Autonomous Warehouse Robot Simulation  (all sensors simulated)")
        self.sim = sim
        self.clock = pygame.time.Clock()
        self.f_s, self.f_m, self.f_b = _font(12), _font(14), _font(14, True)
        self.f_t = _font(15, True)
        self.f_cell = _font(11, True)
        self.running = True
        self.speed_idx = 0
        self.show_explored = True
        self.show_sensors = True
        self.message = ("Add a task, then press START (S)", C["dim"])
        self.hover_cell = None
        self.pkg_input = TextInput((910 + 36, 142 + 26, 108, 24), "PKG-001", 10)
        self.dest_input = TextInput((910 + 232, 142 + 26, 56, 24), "D1", 4)
        self._layout()
        self._build_widgets()

    # ------------------------------------------------------------ layout
    def _layout(self) -> None:
        self.r_canvas = pygame.Rect(10, 10, 880, 494)
        self.r_legend = pygame.Rect(10, 508, 880, 22)
        self.r_log = pygame.Rect(10, 534, 880, 176)
        self.r_ctrl = pygame.Rect(900, 10, 370, 126)
        self.r_task = pygame.Rect(900, 142, 370, 172)
        self.r_status = pygame.Rect(900, 320, 370, 180)
        self.r_metrics = pygame.Rect(900, 506, 370, 204)
        wh = self.sim.warehouse
        self.cs = max(8, min((self.r_canvas.w - 24) // wh.width, (self.r_canvas.h - 24) // wh.height))
        self.ox, self.oy = self.r_canvas.x + 22, self.r_canvas.y + 22

    def _build_widgets(self) -> None:
        w3 = 114
        def mk(c, rx, ry, w, label, fn, color=(52, 62, 86), **kw):
            return Button((c.x + rx, c.y + ry, w, 28), label, fn, color, **kw)

        c = self.r_ctrl
        self.buttons = [
            mk(c, 10, 24, w3, "START (S)", lambda: self.say(self.sim.start()), (40, 100, 64),
               active=lambda: self.sim.running and not self.sim.paused),
            mk(c, 10 + w3 + 4, 24, w3, "PAUSE (P)", lambda: self.say(self.sim.pause()), (100, 84, 36),
               active=lambda: self.sim.paused),
            mk(c, 10 + 2 * (w3 + 4), 24, w3, "RESUME (R)", lambda: self.say(self.sim.resume()), (40, 84, 110)),
            mk(c, 10, 56, w3, "RESET (N)", self.do_reset, (80, 60, 100)),
            mk(c, 10 + w3 + 4, 56, 2 * w3 + 4, "EMERGENCY STOP (SPACE)",
               lambda: self.say(self.sim.emergency_stop(), C["err"]), (150, 36, 36),
               active=lambda: self.sim.robot.estopped),
            mk(c, 10, 88, 84, "Explored", self.toggle_explored, active=lambda: self.show_explored),
            mk(c, 98, 88, 84, "Sensors", self.toggle_sensors, active=lambda: self.show_sensors),
            mk(c, 186, 88, 84, "", self.toggle_recog,
               label_fn=lambda: "Rec:" + ("CV" if self.sim.recognition_mode == "opencv" else "SENS")),
            mk(c, 274, 88, 84, "", self.cycle_speed, label_fn=lambda: f"Speed {self.SPEEDS[self.speed_idx]}x"),
        ]
        t = self.r_task
        self.buttons += [
            Button((t.x + 184, t.y + 26, 24, 24), ">", self.cycle_package),
            Button((t.x + 294, t.y + 26, 24, 24), ">", self.cycle_destination),
            Button((t.x + 10, t.y + 56, 112, 26), "ADD TASK", self.add_task, (40, 100, 64)),
            Button((t.x + 126, t.y + 56, 112, 26), "DEMO TASKS", lambda: self.say(self.sim.add_demo_tasks())),
            Button((t.x + 242, t.y + 56, 118, 26), "TO CHARGER (C)", lambda: self.say(self.sim.go_to_charger())),
        ]
        self.pkg_input.rect = pygame.Rect(t.x + 36, t.y + 26, 144, 24)
        self.dest_input.rect = pygame.Rect(t.x + 242, t.y + 26, 48, 24)

    # ----------------------------------------------------------- actions
    def say(self, text: str, color=None) -> None:
        self.message = (text, color or C["info"])

    def do_reset(self) -> None:
        self.say(self.sim.reset(), C["warn"])

    def toggle_explored(self) -> None:
        self.show_explored = not self.show_explored

    def toggle_sensors(self) -> None:
        self.show_sensors = not self.show_sensors

    def toggle_recog(self) -> None:
        mode = "opencv" if self.sim.recognition_mode == "sensor" else "sensor"
        self.say(self.sim.set_recognition_mode(mode))

    def cycle_speed(self) -> None:
        self.speed_idx = (self.speed_idx + 1) % len(self.SPEEDS)

    def add_task(self) -> None:
        res = self.sim.add_task(self.pkg_input.text, self.dest_input.text)
        self.say(res.message, C["ok"] if res.ok else C["err"])

    def cycle_package(self) -> None:
        ids = [p.id for p in self.sim.packages.all() if p.status is PackageStatus.STORED]
        if ids:
            cur = self.pkg_input.text
            nxt = ids[(ids.index(cur) + 1) % len(ids)] if cur in ids else ids[0]
            self.pkg_input.text = nxt

    def cycle_destination(self) -> None:
        names = sorted(self.sim.warehouse.delivery_points)
        cur = self.dest_input.text
        self.dest_input.text = names[(names.index(cur) + 1) % len(names)] if cur in names else names[0]

    # ------------------------------------------------------------ events
    def handle_event(self, event) -> None:
        if event.type == pygame.QUIT:
            self.running = False
            return
        for inp in (self.pkg_input, self.dest_input):
            if inp.handle(event) == "submit":
                self.add_task()
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.buttons:
                if b.handle(event):
                    return
            cell = self.px_to_cell(event.pos)
            if cell is not None:
                self.say(self.sim.toggle_crate(cell))
        elif event.type == pygame.MOUSEMOTION:
            self.hover_cell = self.px_to_cell(event.pos)
        elif event.type == pygame.KEYDOWN and not (self.pkg_input.focused or self.dest_input.focused):
            k = event.key
            if k == pygame.K_ESCAPE:
                self.running = False
            elif k == pygame.K_s:
                self.say(self.sim.start())
            elif k == pygame.K_p:
                self.say(self.sim.pause())
            elif k == pygame.K_r:
                self.say(self.sim.resume())
            elif k == pygame.K_n:
                self.do_reset()
            elif k == pygame.K_SPACE:
                self.say(self.sim.emergency_stop(), C["err"])
            elif k == pygame.K_c:
                self.say(self.sim.go_to_charger())
            elif k == pygame.K_d:
                self.say(self.sim.add_demo_tasks())
            elif k == pygame.K_e:
                self.toggle_explored()
            elif k == pygame.K_v:
                self.toggle_sensors()
            elif pygame.K_1 <= k <= pygame.K_4:
                self.speed_idx = k - pygame.K_1

    def px_to_cell(self, pos):
        wh = self.sim.warehouse
        cx, cy = (pos[0] - self.ox) // self.cs, (pos[1] - self.oy) // self.cs
        if pos[0] >= self.ox and pos[1] >= self.oy and 0 <= cx < wh.width and 0 <= cy < wh.height:
            return (int(cx), int(cy))
        return None

    # -------------------------------------------------------------- loop
    def run(self, max_frames: Optional[int] = None) -> None:
        frames = 0
        while self.running:
            dt = min(self.clock.tick(60) / 1000.0, 0.1)
            for event in pygame.event.get():
                self.handle_event(event)
            self.sim.update(dt * self.SPEEDS[self.speed_idx])
            self.render()
            pygame.display.flip()
            frames += 1
            if max_frames is not None and frames >= max_frames:
                break

    # ---------------------------------------------------------- drawing
    def txt(self, s, pos, font=None, color=None, right=False):
        img = (font or self.f_m).render(str(s), True, color or C["text"])
        rect = img.get_rect(topright=pos) if right else img.get_rect(topleft=pos)
        self.screen.blit(img, rect)
        return rect

    def fit(self, s, font, width):
        while len(s) > 4 and font.size(s)[0] > width:
            s = s[:-4] + "..."
        return s

    def panel(self, rect, title):
        pygame.draw.rect(self.screen, C["panel"], rect, border_radius=8)
        pygame.draw.rect(self.screen, C["panel_edge"], rect, 1, border_radius=8)
        self.txt(title, (rect.x + 10, rect.y + 5), self.f_t, C["title"])

    def render(self) -> None:
        self.screen.fill(C["bg"])
        self.draw_canvas()
        self.draw_legend()
        self.draw_log()
        self.draw_controls()
        self.draw_tasks()
        self.draw_status()
        self.draw_metrics()

    def cell_rect(self, x, y):
        return pygame.Rect(self.ox + x * self.cs, self.oy + y * self.cs, self.cs, self.cs)

    def center(self, fx, fy):
        return (self.ox + (fx + 0.5) * self.cs, self.oy + (fy + 0.5) * self.cs)

    # ---- canvas ---------------------------------------------------------
    def draw_canvas(self) -> None:
        sim, wh, cs, scr = self.sim, self.sim.warehouse, self.cs, self.screen
        pygame.draw.rect(scr, C["panel"], self.r_canvas, border_radius=8)
        pygame.draw.rect(scr, C["panel_edge"], self.r_canvas, 1, border_radius=8)
        for x in range(wh.width):                                   # coordinate labels
            self.txt(x, (self.ox + x * cs + cs // 2 - 3 * len(str(x)), self.r_canvas.y + 5), self.f_s, C["dim"])
        for y in range(wh.height):
            self.txt(y, (self.r_canvas.x + 5, self.oy + y * cs + cs // 2 - 7), self.f_s, C["dim"])

        pickup_stripe = (112, 100, 40)
        for y in range(wh.height):
            for x in range(wh.width):
                r = self.cell_rect(x, y)
                t = wh.grid[y][x]
                if t is CellType.WALL:
                    pygame.draw.rect(scr, C["wall"], r)
                    pygame.draw.rect(scr, C["wall_in"], r.inflate(-6, -6))
                elif t is CellType.SHELF:
                    pygame.draw.rect(scr, C["shelf"], r)
                    pygame.draw.rect(scr, C["shelf_in"], r.inflate(-6, -6))
                    pygame.draw.line(scr, C["shelf"], (r.x + 3, r.centery), (r.right - 4, r.centery))
                else:
                    base = {CellType.CHARGER: C["charger"], CellType.PICKUP: C["pickup"],
                            CellType.DELIVERY: C["delivery"]}.get(t, C["free"])
                    pygame.draw.rect(scr, base, r)
                    pygame.draw.rect(scr, C["grid"], r, 1)
                    if t is CellType.PICKUP:
                        for k in range(0, cs, 8):
                            pygame.draw.line(scr, pickup_stripe, (r.x + k, r.bottom - 1), (r.x + k + 6, r.y + 1))
                    if t is CellType.CHARGER:
                        cx, cy = r.center
                        pts = [(cx + 2, cy - cs * .35), (cx - cs * .18, cy + 1), (cx, cy + 1),
                               (cx - 2, cy + cs * .35), (cx + cs * .18, cy - 1), (cx, cy - 1)]
                        pygame.draw.polygon(scr, (255, 226, 90), pts)
        for name, (x, y) in wh.delivery_points.items():              # delivery labels
            r = self.cell_rect(x, y)
            pygame.draw.rect(scr, (70, 200, 110), r, 2)
            self.txt(name, (r.x + 2, r.y + 1), self.f_cell, (170, 255, 190))

        for p in sim.packages.all():                                 # delivered packages
            if p.status is PackageStatus.DELIVERED and p.delivered_cell:
                same = sim.packages.delivered_at(p.delivered_cell)
                i = same.index(p)
                r = self.cell_rect(*p.delivered_cell)
                s = max(6, cs // 3)
                pygame.draw.rect(scr, p.color, (r.x + 2 + (i % 2) * (s + 2), r.bottom - s - 2 - (i // 2) * (s + 2), s, s),
                                 border_radius=2)
        active_pkg = sim.robot.package.id if sim.robot.package else None
        queued = {t.package_id for t in sim.tasks.queue}
        pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() / 200.0)
        for cell, pid in list(wh.package_at.items()):
            p = sim.packages.get(pid)
            r = self.cell_rect(*cell).inflate(-cs * 0.34, -cs * 0.34)
            pygame.draw.rect(scr, p.color, r, border_radius=3)
            pygame.draw.rect(scr, (240, 240, 240), r, 1, border_radius=3)
            lab = self.f_cell.render(f"{p.number:02d}", True, (255, 255, 255))
            scr.blit(lab, lab.get_rect(center=r.center))
            if pid == active_pkg:
                pygame.draw.rect(scr, (255, 240, 90), self.cell_rect(*cell).inflate(-2, -2),
                                 2 + int(pulse * 2), border_radius=4)
            elif pid in queued:
                pygame.draw.rect(scr, (90, 200, 255), self.cell_rect(*cell).inflate(-2, -2), 1, border_radius=4)

        overlay = pygame.Surface((self.r_canvas.w, self.r_canvas.h), pygame.SRCALPHA)
        robot = sim.robot
        if self.show_explored and robot.explored:                    # A* explored nodes
            n = len(robot.explored)
            if robot.state is RobotState.PLANNING:
                n = int(n * robot.plan_progress)
            for (x, y) in robot.explored[:n]:
                r = self.cell_rect(x, y).move(-self.r_canvas.x, -self.r_canvas.y).inflate(-2, -2)
                pygame.draw.rect(overlay, C["explored"], r)
        for g in robot.goals if robot.task or robot.mission else ():  # goal cells
            r = self.cell_rect(*g).move(-self.r_canvas.x, -self.r_canvas.y).inflate(-4, -4)
            pygame.draw.rect(overlay, (255, 214, 70, 150), r, 2)
        scr.blit(overlay, self.r_canvas.topleft)

        if robot.path and robot.state is not RobotState.PLANNING:    # planned path
            pts = [self.center(*robot.float_pos())] + [self.center(*c) for c in robot.path[robot.path_index + 1:]]
            if len(pts) > 1:
                pygame.draw.lines(scr, C["path"], False, pts, 3)
                for p_ in pts[1:]:
                    pygame.draw.circle(scr, C["path"], p_, 3)

        for o in wh.obstacles:                                       # movable obstacles
            fx, fy = o.pos
            r = pygame.Rect(self.ox + fx * cs, self.oy + fy * cs, cs, cs).inflate(-5, -5)
            if o.kind == "cart":
                pygame.draw.rect(scr, (240, 120, 40), r, border_radius=4)
                for k in range(r.x + 4, r.right - 6, 8):
                    pygame.draw.line(scr, (30, 30, 30), (k, r.y + 2), (k + 5, r.bottom - 3), 2)
                pygame.draw.circle(scr, (20, 20, 20), (r.x + 4, r.bottom), 3)
                pygame.draw.circle(scr, (20, 20, 20), (r.right - 4, r.bottom), 3)
            else:
                pygame.draw.rect(scr, (176, 130, 80), r, border_radius=2)
                pygame.draw.rect(scr, (90, 255, 255) if o.user_placed else (110, 80, 40), r, 2, border_radius=2)
                pygame.draw.line(scr, (110, 80, 40), r.topleft, r.bottomright, 2)
                pygame.draw.line(scr, (110, 80, 40), r.topright, r.bottomleft, 2)

        if self.show_sensors:                                        # simulated sensor rays
            cx, cy = self.center(*robot.float_pos())
            for rd in robot.readings.values():
                length = (rd.distance if rd.hit else rd.max_range) - (0.5 if rd.hit else 0.0)
                end = (cx + rd.direction[0] * length * cs, cy + rd.direction[1] * length * cs)
                pygame.draw.line(scr, C["err"] if rd.hit else (110, 220, 140), (cx, cy), end, 1)
                pygame.draw.circle(scr, C["err"] if rd.hit else (110, 220, 140), end, 3)

        self.draw_robot()

    def draw_robot(self) -> None:
        robot, cs, scr = self.sim.robot, self.cs, self.screen
        cx, cy = self.center(*robot.float_pos())
        col = STATE_COLOR[robot.state]
        body = pygame.Rect(0, 0, cs * 0.78, cs * 0.78)
        body.center = (cx, cy)
        pygame.draw.rect(scr, (20, 24, 32), body.inflate(4, 4), border_radius=7)
        pygame.draw.rect(scr, col, body, border_radius=6)
        a = math.radians(robot.heading_deg)
        d, pp = (math.cos(a), math.sin(a)), (-math.sin(a), math.cos(a))
        tip = (cx + d[0] * cs * .48, cy + d[1] * cs * .48)
        b1 = (cx + d[0] * cs * .08 + pp[0] * cs * .24, cy + d[1] * cs * .08 + pp[1] * cs * .24)
        b2 = (cx + d[0] * cs * .08 - pp[0] * cs * .24, cy + d[1] * cs * .08 - pp[1] * cs * .24)
        pygame.draw.polygon(scr, (20, 24, 32), [tip, b1, b2])
        if robot.carrying:
            pkg = self.sim.packages.get(robot.carrying)
            s = cs * 0.3
            pygame.draw.rect(scr, pkg.color, (cx - d[0] * cs * .12 - s / 2, cy - d[1] * cs * .12 - s / 2, s, s),
                             border_radius=2)
        if robot.estopped:
            pygame.draw.rect(scr, C["err"], body.inflate(8, 8), 3, border_radius=8)

    def draw_legend(self) -> None:
        r = self.r_legend
        x = r.x + 4
        items = [((78, 82, 94), "Wall"), (C["shelf"], "Shelf"), ((220, 80, 80), "Package"),
                 (C["charger"], "Charger"), ((112, 100, 40), "Pickup zone"), (C["delivery"], "Delivery"),
                 ((240, 120, 40), "Cart*"), ((176, 130, 80), "Crate* (click)"), (C["path"], "Path"),
                 ((90, 150, 255), "A* explored")]
        for col, name in items:
            pygame.draw.rect(self.screen, col, (x, r.y + 5, 12, 12), border_radius=2)
            rr = self.txt(name, (x + 16, r.y + 4), self.f_s, C["dim"])
            x = rr.right + 10
        if self.hover_cell and x < r.right - 140:
            self.txt(f"({self.hover_cell[0]},{self.hover_cell[1]}) {self.sim.warehouse.cell_label(self.hover_cell)}",
                     (r.right - 4, r.y + 4), self.f_s, C["text"], right=True)

    # ---- log ------------------------------------------------------------
    def draw_log(self) -> None:
        self.panel(self.r_log, "EVENT LOG   (* = movable obstacle; sensors are simulated)")
        lines = self.sim.log.last(10)
        y = self.r_log.y + 26
        for e in lines:
            line = self.fit(f"[{e.time:7.1f}s] {e.text}", self.f_s, self.r_log.w - 20)
            self.txt(line, (self.r_log.x + 10, y), self.f_s, LEVEL_COLOR.get(e.level, C["text"]))
            y += 14

    # ---- controls ---------------------------------------------------------
    def draw_controls(self) -> None:
        self.panel(self.r_ctrl, "CONTROLS")
        mouse = pygame.mouse.get_pos()
        for b in self.buttons:
            if b.rect.colliderect(self.r_ctrl):
                b.draw(self.screen, self.f_s, mouse)
        sim = self.sim
        flag = "PAUSED" if sim.paused else ("E-STOP" if sim.robot.estopped else ("RUNNING" if sim.running else "STOPPED"))
        col = C["warn"] if sim.paused else (C["err"] if sim.robot.estopped else (C["ok"] if sim.running else C["dim"]))
        self.txt(flag, (self.r_ctrl.right - 10, self.r_ctrl.y + 6), self.f_b, col, right=True)

    # ---- tasks ------------------------------------------------------------
    def draw_tasks(self) -> None:
        t = self.r_task
        self.panel(t, "TASK QUEUE")
        mouse = pygame.mouse.get_pos()
        self.txt("Pkg", (t.x + 10, t.y + 30), self.f_s, C["dim"])
        self.txt("Dest", (t.x + 212, t.y + 30), self.f_s, C["dim"])
        self.pkg_input.draw(self.screen, self.f_m)
        self.dest_input.draw(self.screen, self.f_m)
        for b in self.buttons:
            if b.rect.colliderect(t):
                b.draw(self.screen, self.f_s, mouse)
        self.txt(self.fit(self.message[0], self.f_s, t.w - 20), (t.x + 10, t.y + 88), self.f_s, self.message[1])
        y = t.y + 106
        colors = {TaskStatus.QUEUED: C["info"], TaskStatus.ACTIVE: C["warn"],
                  TaskStatus.COMPLETED: C["ok"], TaskStatus.FAILED: C["err"]}
        recent = self.sim.tasks.recent(4)
        if not recent:
            self.txt(self.fit("No tasks yet - type an ID (e.g. PKG-003) or press DEMO", self.f_s, t.w - 20), (t.x + 10, y), self.f_s, C["dim"])
        for task in recent:
            extra = f" - {task.failure_reason}" if task.failure_reason else ""
            line = self.fit(f"{task.label()}  [{task.status.value}]{extra}", self.f_s, t.w - 20)
            self.txt(line, (t.x + 10, y), self.f_s, colors[task.status])
            y += 15

    # ---- status -----------------------------------------------------------
    def draw_status(self) -> None:
        s, robot, sim = self.r_status, self.sim.robot, self.sim
        self.panel(s, "ROBOT STATUS")
        x, y = s.x + 10, s.y + 26
        col = STATE_COLOR[robot.state]
        badge = pygame.Rect(x, y - 2, 96, 18)
        pygame.draw.rect(self.screen, col, badge, border_radius=4)
        img = self.f_b.render(robot.state.value, True, (15, 15, 20))
        self.screen.blit(img, img.get_rect(center=badge.center))
        self.txt(self.fit(robot.phase, self.f_s, s.w - 120), (x + 104, y + 1), self.f_s, C["text"])
        y += 20
        hd = HEADINGS[int(round(robot.heading_deg / 45.0)) % 8]
        fx, fy = robot.float_pos()
        self.txt(f"Pos cell ({robot.cell[0]},{robot.cell[1]})  xy=({fx:.2f},{fy:.2f})  hdg {hd}", (x, y), self.f_s)
        y += 17
        task = robot.task
        self.txt(f"Task: {task.label() if task else '-'}", (x, y), self.f_s)
        y += 17
        self.txt(f"Carrying: {robot.carrying or '-'}   Route left: {robot.route_remaining} cells", (x, y), self.f_s)
        y += 19
        pct = robot.battery_pct
        bar = pygame.Rect(x, y, 200, 12)
        pygame.draw.rect(self.screen, (14, 16, 22), bar, border_radius=3)
        fill = bar.copy()
        fill.w = int(bar.w * pct / 100)
        pygame.draw.rect(self.screen, C["ok"] if pct > 40 else (C["warn"] if pct > 20 else C["err"]), fill, border_radius=3)
        pygame.draw.rect(self.screen, C["panel_edge"], bar, 1, border_radius=3)
        self.txt(f"Battery {pct:5.1f}%", (x + 208, y - 2), self.f_s)
        y += 18
        rd = robot.readings
        fmt = lambda k: (str(rd[k].distance) if rd.get(k) and rd[k].hit else "-") if rd else "-"
        self.txt(f"Sim. proximity sensors  F:{fmt('front')} L:{fmt('left')} R:{fmt('right')} cells", (x, y), self.f_s)
        y += 17
        det = robot.target_detection or (robot.detections[-1] if robot.detections else None)
        mode = "OpenCV" if sim.recognition_mode == "opencv" else "sensor"
        if det and det.package_id:
            conf = "n/a" if det.confidence is None else f"{det.confidence:.3f}"
            self.txt(self.fit(f"Detected {det.package_id} ({det.category}) conf {conf}", self.f_s, 285), (x, y), self.f_s, C["ok"])
        else:
            self.txt(f"Recognition [{mode}]: no detection yet", (x, y), self.f_s, C["dim"])
        y += 15
        self.txt(f"method: {'synthetic cam + OpenCV' if mode == 'OpenCV' else 'sim. colour sensor + tag'}", (x, y), self.f_s, C["dim"])
        if det is not None and det.frame is not None:                # synthetic camera thumbnail
            try:
                rgb = det.frame[:, :, ::-1].tobytes()
                surf = pygame.image.frombuffer(rgb, (det.frame.shape[1], det.frame.shape[0]), "RGB")
                surf = pygame.transform.scale(surf, (56, 56))
                self.screen.blit(surf, (s.right - 66, s.bottom - 66))
                pygame.draw.rect(self.screen, C["panel_edge"], (s.right - 66, s.bottom - 66, 56, 56), 1)
            except Exception:
                pass

    # ---- metrics ----------------------------------------------------------
    def draw_metrics(self) -> None:
        r, m, sim = self.r_metrics, self.sim.metrics, self.sim
        self.panel(r, "METRICS  (from simulation events)")
        fmt_t = lambda v: "-" if v is None else f"{v:.1f} s"
        rows = [
            ("Distance", f"{m.distance_cells:.1f} cells / {m.distance_m:.1f} m"),
            ("Obstacles encountered", f"{m.obstacles_encountered}  (mov {m.movable_encounters}/static {m.static_encounters})"),
            ("Path replans", str(m.replans)),
            ("A* plans computed", f"{m.plans_computed}"),
            ("Last A*", f"{m.last_nodes_explored} nodes, {m.last_plan_ms:.2f} ms"),
            ("Tasks completed", str(m.tasks_completed)),
            ("Tasks failed", str(m.tasks_failed)),
            ("Last completion time", fmt_t(m.last_completion_time)),
            ("Avg completion time", fmt_t(m.average_completion_time)),
            ("Energy used", f"{m.energy_used:.1f} units"),
            ("Collisions", str(m.collisions)),
            ("Sim time", f"{sim.time:.1f} s"),
        ]
        y = r.y + 27
        for label, value in rows:
            self.txt(label, (r.x + 10, y), self.f_s, C["dim"])
            color = C["err"] if (label == "Collisions" and m.collisions) else (C["err"] if label == "Tasks failed" and m.tasks_failed else C["text"])
            self.txt(self.fit(value, self.f_s, 200), (r.right - 10, y), self.f_s, color, right=True)
            y += 14
