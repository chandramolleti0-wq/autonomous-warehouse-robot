#!/usr/bin/env python3
"""Autonomous Warehouse Robot Simulation - entry point.

    python main.py                     # open the Pygame simulator
    python main.py --demo              # open it with the demo tasks queued and running
    python main.py --headless          # run demo tasks without a window, print a report
    python main.py --config my.json    # use a different warehouse file
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "config" / "warehouse.json"


def parse_args(argv=None) -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Autonomous Warehouse Robot Simulation (2D, no hardware)")
    ap.add_argument("--config", default=str(DEFAULT_CONFIG), help="warehouse JSON file")
    ap.add_argument("--demo", action="store_true", help="queue the config's demo tasks and start")
    ap.add_argument("--headless", action="store_true",
                    help="no window: run the demo tasks to completion and print a report")
    ap.add_argument("--recognition", choices=["sensor", "opencv"], help="override recognition mode")
    ap.add_argument("--max-time", type=float, default=900.0, help="headless simulated-time limit (s)")
    return ap.parse_args(argv)


def run_headless(sim, max_time: float) -> int:
    print(sim.add_demo_tasks())
    ok = sim.run_until_idle(max_time=max_time)
    m = sim.metrics
    print(f"\nFinished: {ok}   simulated time: {sim.time:.1f} s")
    print(f"Tasks completed: {m.tasks_completed}   failed: {m.tasks_failed}")
    print(f"Distance: {m.distance_cells:.1f} cells ({m.distance_m:.1f} m)   energy used: {m.energy_used:.1f}")
    print(f"Obstacles encountered: {m.obstacles_encountered}   replans: {m.replans}   "
          f"A* plans: {m.plans_computed}   collisions: {m.collisions}")
    if m.average_completion_time is not None:
        print(f"Average task completion time: {m.average_completion_time:.1f} s")
    print("\nEvent log (last 25):")
    for e in sim.log.last(25):
        print(f"  [{e.time:7.1f}s] {e.level:7} {e.text}")
    return 0 if ok and m.tasks_failed == 0 and m.collisions == 0 else 1


def main(argv=None) -> int:
    args = parse_args(argv)
    from src.config import ConfigError, load_config
    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2
    if args.recognition:
        cfg["recognition"]["mode"] = args.recognition
    from src.simulation import Simulation
    sim = Simulation(cfg)

    if args.headless:
        return run_headless(sim, args.max_time)

    try:
        import pygame  # noqa: F401
    except ImportError:
        print("Pygame is not installed. Run: pip install -r requirements.txt", file=sys.stderr)
        return 3
    from src.ui import App
    app = App(sim)
    if args.demo:
        app.say(sim.add_demo_tasks())
        sim.start()
    try:
        app.run()
    finally:
        import pygame
        pygame.quit()
    return 0


if __name__ == "__main__":
    sys.exit(main())
