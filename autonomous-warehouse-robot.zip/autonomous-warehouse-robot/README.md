# Autonomous Warehouse Robot Simulation

A fully local, hardware-free 2D simulation of an autonomous warehouse robot that navigates between
shelves, avoids obstacles, identifies a requested package, picks it up, transports it and places it
at a delivery point. Built with **Python + Pygame**, an **A\* planner written from scratch**, and an
optional **OpenCV** recognition module. No ROS, Gazebo, cloud services or paid APIs.

> **Simulation, not hardware.** Every sensor, the "camera", the battery and the robot's motion are
> simulated. See [Simulated vs. real](#simulated-vs-real-hardware-capabilities).

![Obstacle detection and replanning](assets/screenshots/03_obstacle_replan.png)

---

## Contents
1. [Project overview](#1-project-overview)
2. [Problem statement](#2-problem-statement) / [Objectives](#3-objectives)
3. [System architecture](#4-system-architecture)
4. [Algorithms used](#5-algorithms-used)
5. [Installation and execution](#6-installation-and-execution)
6. [Controls](#7-controls)
7. [Sample warehouse layout and configuration](#8-sample-warehouse-layout-and-configuration)
8. [Testing](#9-testing)
9. [Verified features](#10-verified-features) · [Limitations](#11-limitations-and-future-enhancements)
10. [Screenshots](#12-screenshots) · [Internship learning outcomes](#13-internship-learning-outcomes)

## 1. Project overview
A virtual warehouse (26×15 grid) contains walls, shelves holding coloured packages, a pickup zone, a
charging station and three delivery points. A mobile robot receives pickup-and-delivery tasks from a
queue and executes each one autonomously. Moving carts and user-placed crates are *not* on the robot's
map, so it must discover them with simulated proximity sensors, stop before colliding, and re-plan.
A dashboard shows the robot's state, planned route, A\* search, sensor readings, battery and metrics.

## 2. Problem statement
Warehouses need robots that can fetch the right item and deliver it without human steering, while
coping with an environment that changes (people, carts, pallets). This project explores the software
side of that problem — planning, reactive obstacle handling, object identification, task management
and monitoring — in a safe, repeatable simulator that runs on any laptop.

## 3. Objectives
* Implement grid A\* from scratch and visualise its search and resulting path.
* Separate *known* obstacles (map) from *discovered* ones (sensed), and re-plan when blocked.
* Run a complete pick-and-place workflow driven by an explicit state machine.
* Identify packages using a calculated score (never a made-up one).
* Provide task queueing with validation, plus honest, event-derived metrics.
* Keep modules decoupled so ROS / Gazebo / real drivers can replace the simulated parts later.

## 4. System architecture

```
main.py ── CLI (GUI | --demo | --headless | --config)
config/warehouse.json ── map, packages, obstacles, robot/battery parameters, demo tasks

src/
  config.py              load + validate JSON (ConfigError with clear messages)
  path_planning.py       A* (from scratch), GridMap helper
  warehouse.py           grid, static obstacles, movable obstacles (carts/crates)
  obstacle_avoidance.py  SIMULATED ray-cast proximity sensors, obstacle memory, blockage decision
  package_manager.py     package records + lifecycle STORED→ASSIGNED→CARRIED→DELIVERED
  recognition.py         simulated colour-sensor recognizer + OpenCV image recognizer
  task_manager.py        FIFO queue + validation
  robot.py               kinematics, battery, state machine, pick-and-place workflow
  metrics.py             counters + event log
  simulation.py          composition root + controls (start/pause/resume/reset/e-stop)
  ui.py                  Pygame dashboard
tests/  scripts/  assets/screenshots/
```

Dependency direction: `ui → simulation → robot → {planner, sensors, recognition, tasks, packages, warehouse}`.
Only `ui.py` imports Pygame, so the whole simulator also runs headless (`--headless`, all tests).
The sensor and recognizer classes are the seams where ROS topics or real drivers would plug in.

**Robot states** — `IDLE, PLANNING, MOVING, PICKING, DELIVERING, COMPLETED, ERROR` (as required) plus
`CHARGING` (an extension). Meaning: *MOVING* = driving to the package (or charger); *DELIVERING* =
carrying the package to the delivery cell and placing it; *PICKING* = scanning, identifying and
grasping; *ERROR* = failed task, emergency stop, or depleted battery.

**Task workflow** (`robot.py`): receive task → locate package → A\* to the nearest free cell beside
it → drive (sense, stop, re-plan as needed) → stop at pickup position → scan neighbouring cells and
identify the requested package → grasp → A\* to the delivery cell → drive → place → record result.

## 5. Algorithms used
* **A\* (4-directional, unit cost, Manhattan heuristic)** — admissible and consistent here, so the
  returned path is optimal; this is unit-tested against an independent BFS on 25 random grids.
  Supports several goal cells (e.g. every free cell beside a shelf) by using the minimum Manhattan
  distance to any goal as the heuristic. Reports expansion order for visualisation.
* **Simulated ray-cast proximity sensing** — three grid rays (front/left/right, range 3 cells) against
  the ground-truth world. A hit on the *planned route* makes the robot stop **before** entering the
  cell. A final physical interlock re-checks the target cell before every move.
* **Obstacle memory + replanning** — a sensed movable obstacle's cell is remembered for 6 s (or until
  a ray sees it free) and excluded from planning. If no route exists the robot waits and retries; a
  stall timer and a per-task replan cap turn endless blockage into a clean task failure.
* **Package recognition (computed confidence, never random)**
  * *sensor mode*: simulated colour sensor (distance attenuation + seeded Gaussian sensor noise) →
    nearest category by **chromaticity**; confidence = `1 − d_best / d_second`. IDs come from a
    simulated RFID tag read, which carries no confidence.
  * *OpenCV mode*: renders a **synthetic** camera frame (coloured box + 4×4 black/white ID label,
    illumination, noise), then HSV segmentation → contours → bounding box → colour classification and
    label decoding by thresholding. Confidence = `min(colour margin, label contrast/margin score)`.
    If nothing could be measured the confidence is `None` and nothing is displayed.
* **Battery model** — configurable energy per cell and per action, idle drain and charge rate. Before
  each task the robot estimates the energy for pickup → delivery → charger on the known map; if short
  it charges first. A mid-task guard diverts to the charger if the remaining task can no longer be
  completed, then resumes (even while carrying).

## 6. Installation and execution
Developed and tested on **Python 3.12.3** (pygame 2.6.1, pytest 9.1.1, OpenCV 4.13, NumPy 2.4). The code
was also re-verified in a brand-new virtual environment following the steps below (101 tests passed with OpenCV 5.0 / NumPy 2.5). It uses no syntax newer than Python 3.11 (checked with `ast` feature-version 3.11); it has not been run on
3.11 itself.

```bash
# 1. (recommended) create a virtual environment
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate

# 2. install dependencies
pip install -r requirements.txt
#    minimal install (no OpenCV mode):  pip install pygame pytest

# 3. run the simulator
python main.py                       # open the GUI, add tasks yourself
python main.py --demo                # GUI with the 4 demo tasks queued and started
python main.py --headless            # no window: run the demo, print a metrics report
python main.py --recognition opencv  # start in OpenCV recognition mode
python main.py --config my.json      # use another warehouse file
```
Windows: use `python`; macOS/Linux: `python3` if `python` is not on your PATH.
A missing or invalid config exits with code 2 and an explanatory message. If OpenCV is not installed
the app still runs and uses the simulated-sensor recognizer.

## 7. Controls
| Action | Button | Key |
|---|---|---|
| Start processing the queue | START | `S` |
| Pause / resume everything | PAUSE / RESUME | `P` / `R` |
| Emergency stop (latches; `RESUME` releases it) | EMERGENCY STOP | `Space` |
| Reset to clean initial state | RESET | `N` |
| Send robot to charging station | TO CHARGER | `C` |
| Queue the demo tasks | DEMO TASKS | `D` |
| Toggle explored nodes / sensor rays | Explored / Sensors | `E` / `V` |
| Switch recognition mode (simulated sensor ⇄ OpenCV) | Rec:SENS / Rec:CV | |
| Speed 1×/2×/4×/8× | Speed | `1`–`4` |
| Add a task | type a package ID + destination, **ADD TASK** or `Enter` | |
| Place / remove a **crate** (movable obstacle) | left-click a floor cell | |
| Quit | window close | `Esc` |

The `>` buttons beside the text boxes cycle through available packages / destinations. Typing an
unknown ID (e.g. `PKG-777`), an unknown destination, an already-assigned or already-delivered package
shows a validation error and queues nothing.

## 8. Sample warehouse layout and configuration
`config/warehouse.json` (excerpt; `#` wall · `S` shelf · `.` floor · `C` charger · `P` pickup zone · `D` delivery zone):
```
##########################
#C......PPPP.............#
#........................#
#.SSSS..SSSS..SSSS..SSSS.#
#.SSSS..SSSS..SSSS..SSSS.#
#........................#
#.SSSS..SSSS..SSSS..SSSS.#
#.SSSS..SSSS..SSSS..SSSS.#
#........................#
#.SSSS..SSSS..SSSS..SSSS.#
#.SSSS..SSSS..SSSS..SSSS.#
#........................#
#..DDD......DDD......DDD.#
#........................#
##########################
```
Packages sit on shelf (`S`) or pickup-zone (`P`) cells and are picked from an adjacent free cell.
Delivery points `D1`, `D2`, `D3` are named cells inside the `D` zones. The file also defines package
categories/colours, two patrolling carts, one crate, robot speed / sensor range / timings, the battery
model, recognition settings and the demo task list. Invalid files are rejected with a specific message
(e.g. *"package PKG-003 at (3, 3) must be on a shelf 'S' or pickup 'P' cell"*).
Any rectangular layout works — `tests/test_simulation.py` runs a tiny 7×5 custom warehouse.

## 9. Testing
```bash
python -m pytest -q                    # full suite
python -m pytest tests/test_path_planning.py -v
python scripts/fuzz.py 40              # stress test: 40 random scenarios
python scripts/capture_screenshots.py  # regenerate assets/screenshots/*.png (headless)
```
Results of the last run on the final code (Python 3.12.3): **101 passed in ≈9 s**

| File | Tests | Covers |
|---|---|---|
| `test_path_planning.py` | 38 | valid/optimal paths, unreachable goals, diagonal squeeze, blocked goal, multi-goal, replanning around a new obstacle, 25 random grids vs. BFS |
| `test_task_manager.py` | 21 | validation (invalid ID/destination, assigned, delivered, unreachable), FIFO order, full execution, state coverage, picks beside (not on) packages, identifying a package among two neighbours, failure handling, battery/charging |
| `test_simulation.py` | 31 | sensors (static vs. movable), obstacle memory, avoidance, replan-and-deliver, no collisions with carts, pause, e-stop/release, reset equality, recognition (both modes), config errors |
| `test_ui_smoke.py` | 11 | the real Pygame UI driven with real mouse/keyboard events (headless): every button, text input, shortcuts, crate click, full demo run, missing-font fallback |

`scripts/fuzz.py` (40 seeds: random tasks, speeds, recognition modes, crates dropped mid-run) finished
with **0 collisions, 0 illegal cell entries, 0 hangs** over 211 tasks and ≈1,200 replans. 27 of those
tasks *failed* — deliberately so: the random crates sealed routes (25 route-blocked, 2 battery
depleted) and the robot gave up cleanly instead of hanging.

## 10. Verified features
Everything below was exercised by the automated tests above and/or by running the program.

* Configurable warehouse, coordinates, obstacle/traversable distinction, multiple package types ✔
* Robot with heading, all states, start / pause / resume / reset / emergency stop ✔
* A\* from scratch + visualised path and explored nodes + replanning ✔
* Simulated proximity sensors, stop-before-collision, static vs. movable obstacles ✔ (clearly labelled simulated)
* Package recognition with computed confidence (sensor mode and OpenCV mode) ✔
* Full 10-step pick-and-place workflow, multi-task queue, validation, success/error messages ✔
* Metrics from real events: distance, obstacles, replans, tasks done/failed, completion time, energy, collisions ✔
* Reset restores a state identical to a fresh start (`snapshot()` equality test) ✔
* Missing/invalid config and missing fonts handled without crashing ✔
* Demo run: 4/4 tasks completed in 84.6 simulated s, 2 obstacles met, 3 replans, 0 collisions ✔
* The real `python main.py --demo` startup was run under a dummy video driver (ran until killed, no traceback) ✔

## 11. Limitations and future enhancements
**Limitations (be upfront about these)**
* 2D grid world; the robot moves cell-to-cell with no dynamics, wheel slip, localisation error or SLAM.
* Sensors are ray-casts on ground truth with no physical noise model; they are **not** LiDAR or camera
  drivers. The "camera" image is synthetic, so the OpenCV pipeline is a demonstration of image
  processing, not evidence of performance on real photographs. Recognition uses classical methods, no ML.
* Single robot; FIFO scheduling only. Carts move on fixed straight patrol lines.
* If a task fails *after* pickup (e.g. destination boxed in), the package stays on the robot and the
  robot halts until **Reset**; there is no automatic re-stowing.
* Not visually tested on a physical display in this build (screenshots and UI tests ran with SDL's dummy
  driver); the window is resizable and scales to small screens.
* Tested on Python 3.12 only.

**Future work:** ROS 2 bridge (publish `/scan` / `cmd_vel`, keep the planner and task logic), Gazebo
world export, D\* Lite / Theta\* planning, multi-robot reservation tables, task prioritisation and
deadlines, a trained detector fed with real images, and sensor-noise models.

## 12. Screenshots
Generated from the real running UI by `python scripts/capture_screenshots.py`.

| | |
|---|---|
| ![](assets/screenshots/01_initial_warehouse.png) Initial warehouse | ![](assets/screenshots/02_astar_planning_explored_nodes.png) A\* search (explored nodes) |
| ![](assets/screenshots/03_obstacle_replan.png) Obstacle detected → replan | ![](assets/screenshots/04_package_recognition.png) Package identified |
| ![](assets/screenshots/05_delivering.png) Delivering | ![](assets/screenshots/06_all_tasks_completed.png) All tasks completed |
| ![](assets/screenshots/07_opencv_recognition.png) OpenCV mode with synthetic camera frame | |

## 13. Internship learning outcomes
* Designing a layered robotics software stack (planning, perception, control, task layer, UI) with clean seams for real hardware/ROS.
* Implementing and proving an optimal graph-search algorithm (A\*) with unit tests and a BFS oracle.
* Modelling known vs. discovered obstacles and building reactive behaviour: sense → stop → remember → replan, plus deadlock/livelock protection.
* Writing a finite-state-machine controller with safety interlocks, emergency stop and recovery paths.
* Classical computer vision with OpenCV (HSV segmentation, contours, thresholded marker decoding) and producing honest, calculated confidence scores.
* Finding bugs with property/fuzz testing (this project's fuzz run exposed a livelock and a battery-planning flaw that were then fixed).
* Config-driven design with validation, headless CI-friendly testing of a GUI app, and writing honest documentation about what is simulated.
